﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment3
{
    public partial class Form1 : Form
    {
        // Define communites, will initialize later...
        Community dekalb = new Community();
        Community sycamore = new Community();

        //return true if distance is less than maxDistance
        public bool inDistance(uint oneX, uint oneY, uint twoX, uint twoY, double maxDistance)
        {
            double total = Math.Sqrt(Math.Pow((double)oneX - (double)twoX, 2) + Math.Pow((double)oneY - (double)twoY, 2));

            if (total <= maxDistance)
            {
                return true;
            }
            //else
            return false;
        }

        public uint distance(uint oneX, uint oneY, uint twoX, uint twoY, double maxDistance)
        {
            double total = Math.Sqrt(Math.Pow((double)oneX - (double)twoX, 2) + Math.Pow((double)oneY - (double)twoY, 2));
            return (uint)total;
        }

        public Form1()
        {
            InitializeComponent();

            // For some reason files are stored from "../../../file" rather than "../../file" like last assignment...

            // Create and populate DeKalb community...
            if (Directory.Exists("../../../DeKalb"))
            {
                // Define variables...
                SortedSet<Person> persons = new SortedSet<Person>();
                SortedSet<Property> props = new SortedSet<Property>();

                // Read in input data...
                string inputData;
                Nullable<UInt32> mayorId = null;

                // Read in people data...            
                if (File.Exists("../../../DeKalb/p.txt"))
                {
                    using (StreamReader inFile = new StreamReader("../../../DeKalb/p.txt"))
                    {
                        inputData = inFile.ReadLine();
                        while (inputData != null)
                        {
                            string[] personParams = inputData.Split();

                            // Get first person as mayor.
                            if (mayorId == null) mayorId = Convert.ToUInt32(personParams[0]);

                            Person newPerson = new Person(personParams);

                            persons.Add(newPerson);

                            inputData = inFile.ReadLine();
                        }
                    }
                }

                // Read in house data...            
                if (File.Exists("../../../DeKalb/r.txt"))
                {
                    using (StreamReader inFile = new StreamReader("../../../DeKalb/r.txt"))
                    {
                        inputData = inFile.ReadLine();
                        while (inputData != null)
                        {
                            string[] houseParams = new string[inputData.Split().Length];
                            houseParams = inputData.Split();

                            House newhouse = new House(houseParams);

                            props.Add(newhouse);

                            inputData = inFile.ReadLine();
                        }
                    }
                }

                // Read in apartment data...
                if (File.Exists("../../../DeKalb/a.txt"))
                {
                    using (StreamReader inFile = new StreamReader("../../../DeKalb/a.txt"))
                    {
                        inputData = inFile.ReadLine();
                        while (inputData != null)
                        {
                            string[] apartParams = new string[inputData.Split().Length];
                            apartParams = inputData.Split();

                            Apartment newApartment = new Apartment(apartParams);

                            props.Add(newApartment);

                            inputData = inFile.ReadLine();
                        }
                    }
                }

                // Read in business data...
                if (File.Exists("../../../DeKalb/b.txt"))
                {
                    using (StreamReader inFile = new StreamReader("../../../DeKalb/b.txt"))
                    {
                        inputData = inFile.ReadLine();
                        while (inputData != null)
                        {
                            string[] businessParams = new string[inputData.Split().Length];
                            businessParams = inputData.Split();

                            Business newBusiness = new Business(businessParams);

                            props.Add(newBusiness);

                            inputData = inFile.ReadLine();
                        }
                    }
                }

                // Read in school data...
                if (File.Exists("../../../DeKalb/s.txt"))
                {
                    using (StreamReader inFile = new StreamReader("../../../DeKalb/s.txt"))
                    {
                        inputData = inFile.ReadLine();
                        while (inputData != null)
                        {
                            string[] schoolParams = new string[inputData.Split().Length];
                            schoolParams = inputData.Split();

                            School newSchool = new School(schoolParams);

                            props.Add(newSchool);

                            inputData = inFile.ReadLine();
                        }
                    }
                }

                // After reading in all the input data...
                dekalb = new Community(props, persons, Convert.ToString(99999), "DeKalb", Convert.ToString(mayorId));
            }

            // Create and populate Sycamore community...
            if (Directory.Exists("../../../Sycamore"))
            {
                // Define variables...
                SortedSet<Person> persons = new SortedSet<Person>();
                SortedSet<Property> props = new SortedSet<Property>();

                // Read in input data...
                string inputData;
                Nullable<UInt32> mayorId = null;

                // Read in people data...            
                if (File.Exists("../../../Sycamore/p.txt"))
                {
                    using (StreamReader inFile = new StreamReader("../../../Sycamore/p.txt"))
                    {
                        inputData = inFile.ReadLine();
                        while (inputData != null)
                        {
                            string[] personParams = inputData.Split();

                            // Get first person as mayor.
                            if (mayorId == null) mayorId = Convert.ToUInt32(personParams[0]);

                            Person newPerson = new Person(personParams);

                            persons.Add(newPerson);

                            inputData = inFile.ReadLine();
                        }
                    }
                }

                // Read in house data...            
                if (File.Exists("../../../Sycamore/r.txt"))
                {
                    using (StreamReader inFile = new StreamReader("../../../Sycamore/r.txt"))
                    {
                        inputData = inFile.ReadLine();
                        while (inputData != null)
                        {
                            string[] houseParams = new string[inputData.Split().Length];
                            houseParams = inputData.Split();

                            House newhouse = new House(houseParams);

                            props.Add(newhouse);

                            inputData = inFile.ReadLine();
                        }
                    }
                }

                // Read in apartment data...
                if (File.Exists("../../../Sycamore/a.txt"))
                {
                    using (StreamReader inFile = new StreamReader("../../../Sycamore/a.txt"))
                    {
                        inputData = inFile.ReadLine();
                        while (inputData != null)
                        {
                            string[] apartParams = new string[inputData.Split().Length];
                            apartParams = inputData.Split();

                            Apartment newApartment = new Apartment(apartParams);

                            props.Add(newApartment);

                            inputData = inFile.ReadLine();
                        }
                    }
                }

                // Read in business data...
                if (File.Exists("../../../Sycamore/b.txt"))
                {
                    using (StreamReader inFile = new StreamReader("../../../Sycamore/b.txt"))
                    {
                        inputData = inFile.ReadLine();
                        while (inputData != null)
                        {
                            string[] businessParams = new string[inputData.Split().Length];
                            businessParams = inputData.Split();

                            Business newBusiness = new Business(businessParams);

                            props.Add(newBusiness);

                            inputData = inFile.ReadLine();
                        }
                    }
                }

                // Read in school data...
                if (File.Exists("../../../Sycamore/s.txt"))
                {
                    using (StreamReader inFile = new StreamReader("../../../Sycamore/s.txt"))
                    {
                        inputData = inFile.ReadLine();
                        while (inputData != null)
                        {
                            string[] schoolParams = new string[inputData.Split().Length];
                            schoolParams = inputData.Split();

                            School newSchool = new School(schoolParams);

                            props.Add(newSchool);

                            inputData = inFile.ReadLine();
                        }
                    }
                }

                // After reading in all the input data...
                sycamore = new Community(props, persons, Convert.ToString(9999), "Sycamore", Convert.ToString(mayorId));
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        // Function for Query1 Minimum Price TrackBar value change.
        private void Query1_MinPrice_TrackBar_ValueChanged(object sender, EventArgs e)
        {
            // Min Price cannot be higher than Max Price...
            if (Query1_MinPrice_TrackBar.Value >= Query1_MaxPrice_TrackBar.Value)
            {
                Query1_MinPrice_TrackBar.Value = Query1_MaxPrice_TrackBar.Value;
            }

            Query1_MinPrice_Label.Text = String.Format("Min Price: {0:  $#,#0}", Query1_MinPrice_TrackBar.Value);
        }

        // Function for Query1 Maximum Price TrackBar value change.
        private void Query1_MaxPrice_TrackBar_ValueChanged(object sender, EventArgs e)
        {
            // Max Price cannot be lower than Min Price...
            if (Query1_MaxPrice_TrackBar.Value <= Query1_MinPrice_TrackBar.Value)
            {
                Query1_MaxPrice_TrackBar.Value = Query1_MinPrice_TrackBar.Value;
            }

            Query1_MaxPrice_Label.Text = String.Format("Max Price: {0:  $#,#0}", Query1_MaxPrice_TrackBar.Value);
        }

        // Get the query for For Sale Properties Within Price Range.
        private void Query1_Button_Click(object sender, EventArgs e)
        {
            // Error checking...
            if (!Query1_Residential_CheckBox.Checked &&
                !Query1_School_CheckBox.Checked &&
                !Query1_Business_CheckBox.Checked)
            {
                QueryResults_TextBox.Text = "ERROR: Please check 'Residential', 'School', and/or 'Business'";
                return;
            }

            // Print header...
            QueryResults_TextBox.Text = String.Format("Properties for sale within the [ {0: $#,#0}, {1: $#,#0} ] price range.",
                                                        Query1_MinPrice_TrackBar.Value, Query1_MaxPrice_TrackBar.Value);
            QueryResults_TextBox.Text += "\n------------------------------------------------------------------";

            // Calculate Query...
            var PropertiesQuery =
                from P in dekalb.Props.Concat(sycamore.Props)
                where (Query1_Residential_CheckBox.Checked && P is Residental) ||
                       (Query1_School_CheckBox.Checked && P is School) ||
                       (Query1_Business_CheckBox.Checked && P is Business)
                where P.Forsale > 0     //check if for sale
                where P.Forsale >= Query1_MinPrice_TrackBar.Value && P.Forsale <= Query1_MaxPrice_TrackBar.Value
                orderby P.Forsale ascending
                group P by P.City;

            // Loop over each Community first...
            foreach (var Communities in PropertiesQuery)
            {
                // Print appropriate header...
                if (Communities.Key == "DeKalb") QueryResults_TextBox.Text += "\n       #### DeKalb ####\n";
                else QueryResults_TextBox.Text += "\n       #### Sycamore ####\n";

                // Now loop over each Property in the Community...
                foreach (Property p in Communities)
                {
                    // Depending on Property type, print the appropriate message...
                    if (p is House)
                    {
                        House h = p as House;

                        QueryResults_TextBox.Text += "\n" + h.ToString("address");
                        QueryResults_TextBox.Text += "\n" + "Owner: ";

                        string ownerName = "No Owner";

                        // Find owner...check both communities...
                        foreach (Person person in dekalb.Residents.Concat(sycamore.Residents))
                        {
                            if (person.Id == h.OwnerID)
                            {
                                ownerName = person.FullName;
                            }
                        }

                        QueryResults_TextBox.Text += ownerName + " | ";

                        if (h.Bedrooms == 1) QueryResults_TextBox.Text += "1 bed, ";
                        else QueryResults_TextBox.Text += h.Bedrooms + " beds, ";

                        if (h.Baths == 1) QueryResults_TextBox.Text += "1 bath, ";
                        else QueryResults_TextBox.Text += h.Baths + " baths, ";

                        QueryResults_TextBox.Text += h.Sqft + "sq.ft";

                        QueryResults_TextBox.Text += "\n" + h.ToString("garageInfo");

                        QueryResults_TextBox.Text += String.Format(" {0: $#,#0}", h.Forsale) + "\n";
                    }
                    else if (p is Apartment)
                    {
                        Apartment a = p as Apartment;

                        QueryResults_TextBox.Text += "\n" + a.ToString("address");
                        QueryResults_TextBox.Text += "\n" + "Owner: ";

                        string ownerName = "No Owner";

                        // Find owner...check both communities...
                        foreach (Person person in dekalb.Residents.Concat(sycamore.Residents))
                        {
                            if (person.Id == a.OwnerID)
                            {
                                ownerName = person.FullName;
                            }
                        }

                        QueryResults_TextBox.Text += ownerName + " | ";

                        if (a.Bedrooms == 1) QueryResults_TextBox.Text += "1 bed, ";
                        else QueryResults_TextBox.Text += a.Bedrooms + " beds, ";

                        if (a.Baths == 1) QueryResults_TextBox.Text += "1 bath, ";
                        else QueryResults_TextBox.Text += a.Baths + " baths, ";

                        QueryResults_TextBox.Text += a.Sqft + "sq.ft";

                        QueryResults_TextBox.Text += String.Format(" {0: $#,#0}", a.Forsale) + "\n";
                    }
                    else if (p is Business)
                    {
                        Business b = p as Business;

                        QueryResults_TextBox.Text += "\n" + b.ToString("address");

                        string ownerName = "No Owner";

                        // Find owner...check both communities...
                        foreach (Person person in dekalb.Residents.Concat(sycamore.Residents))
                        {
                            if (person.Id == b.OwnerID)
                            {
                                ownerName = person.FullName;
                            }
                        }

                        QueryResults_TextBox.Text += "\nOwner: " + ownerName + " | ";
                        QueryResults_TextBox.Text += String.Format(" {0: $#,#0}", b.Forsale);

                        QueryResults_TextBox.Text += "\n" + b.ToString("storeInfo") + "\n";
                    }
                    else
                    {
                        School s = p as School;

                        QueryResults_TextBox.Text += "\n" + s.ToString("address");

                        string ownerName = "No Owner";

                        // Find owner...check both communities...
                        foreach (Person person in dekalb.Residents.Concat(sycamore.Residents))
                        {
                            if (person.Id == s.OwnerID)
                            {
                                ownerName = person.FullName;
                            }
                        }

                        QueryResults_TextBox.Text += " | Owner: " + ownerName;
                        QueryResults_TextBox.Text += "\n" + s.ToString("schoolInfo");
                        QueryResults_TextBox.Text += "\n" + s.Enrolled + " students enrolled ";
                        QueryResults_TextBox.Text += String.Format(" {0: $#,#0}", p.Forsale) + "\n";
                    }
                }
            }

            QueryResults_TextBox.Text += "\n### END OF OUTPUT ###";
        }

        private void Query2_School_ComboBox_DropDown(object sender, EventArgs e)
        {
            Query2_School_ComboBox.Items.Clear();

            Query2_School_ComboBox.Items.Add("Dekalb:");
            Query2_School_ComboBox.Items.Add("-------");

            //add school to combo box that are in dekalb
            foreach (Property p in dekalb.Props)
            {
                if (p is School)
                {
                    Query2_School_ComboBox.Items.Add(p.ToString("NAME"));
                }
            }

            Query2_School_ComboBox.Items.Add("  ");

            Query2_School_ComboBox.Items.Add("Sycamore:");
            Query2_School_ComboBox.Items.Add("-------");

            //add school to combo box that are in sycamore
            foreach (Property p in sycamore.Props)
            {
                if (p is School)
                {
                    Query2_School_ComboBox.Items.Add(p.ToString("NAME"));
                }
            }

        }

        // Get the query for For Sale Residences Within Range of a School.
        private void Query2_Button_Click(object sender, EventArgs e)
        {
            QueryResults_TextBox.Clear();

            //error checking for event
            if (Query2_School_ComboBox.SelectedItem == null)
            {
                QueryResults_TextBox.Text = "Your query yielded no matches!";
                return;
            }
            string checker = Query2_School_ComboBox.SelectedItem.ToString();
            if (checker == "" || checker == "Dekalb:" || checker == "Sycamore:" || checker == "-------" || checker == "     ")
            {
                QueryResults_TextBox.Text = "Your query yielded no matches!";
                return;
            }

            Property holdholdVal = new Property();
            bool foundSchool = false;
            string runCommun = "";
            foreach (Property p in dekalb.Props)
            {
                if (Query2_School_ComboBox.SelectedItem.ToString() != p.ToString("NAME"))
                {
                    continue;
                }
                else if (p is School)
                {
                    holdholdVal = (School)p;
                }

                foundSchool = true;
                runCommun = "Dekalb";
                break;
            }
            foreach (Property p in sycamore.Props)
            {
                if (foundSchool) break;
                else if (Query2_School_ComboBox.SelectedItem.ToString() != p.ToString("NAME"))
                {
                    continue;
                }
                else if (p is School)
                {
                    holdholdVal = (School)p;
                }
                foundSchool = true;
                runCommun = "Sycamore";
            }

            //should always be found 
            if (!foundSchool)
            {
                QueryResults_TextBox.Text = "Your query yielded no matches!";
                return;
            }

            //coordinate of school, add 250 to x if in sycamore
            uint holdholdVal_x = holdholdVal.X;
            uint holdholdVal_y = holdholdVal.Y;
            //if the School is in sycamore add 250 to its x value
            if (runCommun == "Sycamore")
                holdholdVal_x += 250;


            //Linq Query for Dekalb
            var myLinqQueryDekalb = from j in dekalb.Props
                                    where j.Forsale > 0
                                    where j is Apartment || j is House
                                    where inDistance(j.X, j.Y, holdholdVal_x, holdholdVal_y, (double)Query2_Distance_UpDown.Value)
                                    select j;
            //Linq Query for Sycamore 
            var myLinqQuerySycamore = from j in sycamore.Props
                                      where j.Forsale > 0
                                      where j is Apartment || j is House
                                      where inDistance((j.X + 250), j.Y, holdholdVal_x, holdholdVal_y, (double)Query2_Distance_UpDown.Value)
                                      select j;

            //a var with all values
            var totalQuery = myLinqQueryDekalb.Concat(myLinqQuerySycamore);
            StringBuilder holdvars = new StringBuilder("");
            
            //check if any value was found
            if (totalQuery.Count() == 0)
            {
                QueryResults_TextBox.Text = "Your query yielded no matches!";
                return;
            }
            if (totalQuery.Count() != 0)
            {
                //Header for text box
                holdvars.Append(string.Format("Residences for sale within {0} units of distance\n   from {1}",
                                Query2_Distance_UpDown.Value.ToString(), Query2_School_ComboBox.SelectedItem.ToString()));
                holdvars.Append("\n-----------------------------------------------------------\n");
                
                //out put for propertys that are close to school and in dekalb
                foreach (var outVars in myLinqQueryDekalb)
                {
                    string nameofOwner = "";

                    //find owner of property
                    foreach (Person per in dekalb.Residents.Concat(sycamore.Residents))
                    {

                        if (outVars.OwnerID.CompareTo(per.Id) == 0)
                        {
                            nameofOwner = (string.Format("{0}, {1}", per.FirstName, per.LastName));
                        }
                    }

                    //outbox format for found propert
                    holdvars.Append(outVars.ToString(distance(outVars.X, outVars.Y, holdholdVal_x, holdholdVal_y, (double)Query2_Distance_UpDown.Value), nameofOwner));
                    holdvars.Append("\n\n");
                }

                //out put for propertys that are close to school and in sycamore
                foreach (var outVars in myLinqQuerySycamore)
                {
                    string nameofOwner = "";

                    //findowner of property
                    foreach (Person per in dekalb.Residents.Concat(sycamore.Residents))
                    {
                        //findowner
                        if (outVars.OwnerID.CompareTo(per.Id) == 0)
                        {
                            nameofOwner = (string.Format("{0}, {1}", per.FirstName, per.LastName));
                        }
                    }

                    //add to outox
                    holdvars.Append(outVars.ToString(distance((outVars.X + 250), outVars.Y, holdholdVal_x, holdholdVal_y, (double)Query2_Distance_UpDown.Value), nameofOwner));
                    holdvars.Append("\n\n");
                }
                holdvars.Append("### END OF OUTPUT ###");
            }

            //publish to textbox
            QueryResults_TextBox.Text = holdvars.ToString();
        }

        private void Query3_ForSaleResidence_ComboBox_DropDown(object sender, EventArgs e)
        {
            Query3_ForSaleResidence_ComboBox.Items.Clear();

            Query3_ForSaleResidence_ComboBox.Items.Add("Dekalb:");
            Query3_ForSaleResidence_ComboBox.Items.Add("-------");

            //add dekalb propertys that are Houses
            foreach (Property p in dekalb.Props)
            {
                if (p is House)
                {
                    Query3_ForSaleResidence_ComboBox.Items.Add(p.ToString("out"));
                }
            }

            Query3_ForSaleResidence_ComboBox.Items.Add("    ");

            //add dekalb propertys that are Houses
            foreach (Property p in dekalb.Props)
            {
                if (p is Apartment)
                {
                    Query3_ForSaleResidence_ComboBox.Items.Add(p.ToString("out"));
                }
            }

            Query3_ForSaleResidence_ComboBox.Items.Add("    ");
            Query3_ForSaleResidence_ComboBox.Items.Add("Sycamore:");
            Query3_ForSaleResidence_ComboBox.Items.Add("-------");

            //add sycamore propertys that are House
            foreach (Property p in sycamore.Props)
            {
                if (p is House)
                {
                    Query3_ForSaleResidence_ComboBox.Items.Add(p.ToString("out"));
                }
            }

            Query3_ForSaleResidence_ComboBox.Items.Add("    ");

            //add sycamore propertys that are apartments
            foreach (Property p in sycamore.Props)
            {
                if (p is Apartment)
                {
                    Query3_ForSaleResidence_ComboBox.Items.Add(p.ToString("out"));
                }
            }
        }

        // Get the query for Hiring Business(es) Within Range of For Sale Residence.
        private void Query3_Button_Click(object sender, EventArgs e)
        {
            QueryResults_TextBox.Clear();

            //error checking for event
            if (Query3_ForSaleResidence_ComboBox.SelectedItem == null)
            {
                QueryResults_TextBox.Text = "Your query yielded no matches!";
                return;
            }

            string checker = Query3_ForSaleResidence_ComboBox.SelectedItem.ToString();
            if (checker == "" || checker == "Dekalb:" || checker == "Sycamore:" || checker == "-------" || checker == "     ")
            {
                QueryResults_TextBox.Text = "Your query yielded no matches!";
                return;
            }

            Property holdholdVal = null;// = new Property();
            bool foundres = false;
            bool runCommun = false;

            foreach (Property p in dekalb.Props.Concat(sycamore.Props))
            {
                if (p is House || p is Apartment)
                {
                    if (p.ToString("out").CompareTo(Query3_ForSaleResidence_ComboBox.SelectedItem.ToString()) == 0)
                    {
                        holdholdVal = p;
                        foundres = true;

                        if (dekalb.Props.Contains(p)) runCommun = true;
                        else runCommun = false;
                    }
                }
            }

            //should always be found 
            if (!foundres)
            {
                QueryResults_TextBox.Text = "Your query yielded no matches!";
                return;
            }

            //coordinate of residence, add 250 to x if in sycamore
            uint holdholdVal_x = holdholdVal.X;
            uint holdholdVal_y = holdholdVal.Y;
            if (!runCommun)
                holdholdVal_x += 250;

            //Linq Query for dekalb community
            var myLinqQueryDekalb = from j in dekalb.Props
                                    where j is Business
                                    where ((Business)j).ActiveRecruitment > 0
                                    where inDistance(j.X, j.Y, holdholdVal_x, holdholdVal_y, (double)Query3_Distance_UpDown.Value)
                                    select j;
            //Linq query for sycamore community
            var myLinqQuerySycamore = from j in sycamore.Props
                                      where j is Business
                                      where ((Business)j).ActiveRecruitment > 0
                                      where inDistance((j.X + 250), j.Y, holdholdVal_x, holdholdVal_y, (double)Query3_Distance_UpDown.Value)
                                      select j;

            StringBuilder extraholdvars = new StringBuilder("");
            StringBuilder holdvars = new StringBuilder("");
            var totalQuery = myLinqQueryDekalb.Concat(myLinqQuerySycamore);
            if (totalQuery.Count() == 0)
            {
                QueryResults_TextBox.Text = "Your query yielded no matches!";
                return;
            }

            if (totalQuery.Count() != 0)
            {
                holdvars.Append(string.Format("Residences for sale within {0} units of distance\n       from {1}",
                                Query3_Distance_UpDown.Value.ToString(), Query3_ForSaleResidence_ComboBox.SelectedItem.ToString()));
                holdvars.Append("\n-------------------------------------------------------------\n");
                foreach (var outVars in totalQuery)
                {
                    foreach (Person per in dekalb.Residents.Concat(sycamore.Residents))
                    {
                        if (per.Id.CompareTo(outVars.OwnerID) == 0)
                        {
                            extraholdvars.Clear();
                            extraholdvars.Append(string.Format("{0}, {1}", per.FirstName.ToString(), per.LastName.ToString()));
                        }
                        //QueryResults_TextBox.Text = extraholdvars.ToString();
                    }
                    //conditional if ouvars is in sycamore
                    if (sycamore.Props.Contains(outVars))
                        holdvars.Append(outVars.ToString(distance((outVars.X + 250), outVars.Y, holdholdVal_x, holdholdVal_y, (double)Query3_Distance_UpDown.Value), extraholdvars.ToString()));
                    else
                        holdvars.Append(outVars.ToString(distance(outVars.X, outVars.Y, holdholdVal_x, holdholdVal_y, (double)Query3_Distance_UpDown.Value), extraholdvars.ToString()));
                    holdvars.Append("\n\n");
                }
                holdvars.Append("### END OF OUTPUT ###");
            }

            //out put textbox
            QueryResults_TextBox.Text = holdvars.ToString();
        }

        private void Query4_Apartment_CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            // Show/Hide the Query4_Garage_CheckBox depending on Apartment_CheckBox status...
            if (Query4_Apartment_CheckBox.Checked)
            {
                Query4_Garage_CheckBox.Visible = false;
                Query4_Attached_CheckBox.Visible = false;

                Query4_Garage_CheckBox.Checked = false;
                Query4_Attached_CheckBox.Checked = false;
            }
            else
            {
                Query4_Garage_CheckBox.Visible = true;
                Query4_Attached_CheckBox.Visible = false;
            }
        }

        private void Query4_Garage_CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            // Show/Hide the Query4_Attached_CheckBox depending on Garage_CheckBox status...
            if (Query4_Garage_CheckBox.Checked)
            {
                Query4_Attached_CheckBox.Visible = true;
            }
            else
            {
                Query4_Attached_CheckBox.Visible = false;

                Query4_Attached_CheckBox.Checked = false;
            }
        }

        // Get the query for Specific Residence Parameters.
        private void Query4_Button_Click(object sender, EventArgs e)
        {
            // Error checking...
            if (!Query4_House_CheckBox.Checked && !Query4_Apartment_CheckBox.Checked)
            {
                QueryResults_TextBox.Text = "ERROR: Please select 'House' and/or 'Apartment'!";
                return;
            }

            // Look for both Houses and Apartments...
            if (Query4_House_CheckBox.Checked && Query4_Apartment_CheckBox.Checked)
            {
                QueryResults_TextBox.Text = "Houses and Apartments with at least ";

                // If there is only 1 Bedroom...
                if (Query4_Bed_UpDown.Value == 1) QueryResults_TextBox.Text += "1 bed, ";
                else QueryResults_TextBox.Text += Query4_Bed_UpDown.Value + " beds, ";

                // If there is only 1 Bathroom...
                if (Query4_Bath_UpDown.Value == 1) QueryResults_TextBox.Text += "1 bath, ";
                else QueryResults_TextBox.Text += Query4_Bath_UpDown.Value + " baths, ";

                QueryResults_TextBox.Text += "and " + Query4_MinSqFt_UpDown.Value + " sq. footage.";
                QueryResults_TextBox.Text += "\n-------------------------------------------------------------";

                // No Garage because of Apartment search...

                // Begin query of Houses and Apartments...
                var PropQuery =
                    from P in dekalb.Props.Concat(sycamore.Props)
                    where P is House || P is Apartment
                    where P.Forsale != 0
                    where (P as Residental).Bedrooms >= Query4_Bed_UpDown.Value
                    where (P as Residental).Baths >= Query4_Bed_UpDown.Value
                    where (P as Residental).Sqft >= Query4_MinSqFt_UpDown.Value
                    orderby P.Forsale ascending
                    select P;

                // In the case that there are no properties that fit this query...
                if (PropQuery.Count() == 0)
                {
                    QueryResults_TextBox.Text += "\nThere are no properties that fit this query!";
                    QueryResults_TextBox.Text += "\n### END OF OUTPUT ###";
                    return;
                }

                // Print results...
                foreach (Residental r in PropQuery)
                {
                    QueryResults_TextBox.Text += "\n" + r.ToString("address");
                    QueryResults_TextBox.Text += "\n" + "Owner: ";

                    string ownerName = "No Owner";

                    // Find owner...check both communities...
                    foreach (Person p in dekalb.Residents.Concat(sycamore.Residents))
                    {
                        if (p.Id == r.OwnerID)
                        {
                            ownerName = p.FullName;
                        }
                    }

                    QueryResults_TextBox.Text += ownerName + " | ";

                    if (r.Bedrooms == 1) QueryResults_TextBox.Text += "1 bed, ";
                    else QueryResults_TextBox.Text += r.Bedrooms + " beds, ";

                    if (r.Baths == 1) QueryResults_TextBox.Text += "1 bath, ";
                    else QueryResults_TextBox.Text += r.Baths + " baths, ";

                    QueryResults_TextBox.Text += r.Sqft + "sq.ft";

                    if (r is House) QueryResults_TextBox.Text += "\n" + r.ToString("garageInfo");

                    QueryResults_TextBox.Text += String.Format(" {0: $#,#0}", r.Forsale) + "\n";
                }
            }
            // If we are looking for just Houses...
            else if (Query4_House_CheckBox.Checked)
            {
                QueryResults_TextBox.Text = "Houses with at least ";

                // If there is only 1 Bedroom...
                if (Query4_Bed_UpDown.Value == 1) QueryResults_TextBox.Text += "1 bed, ";
                else QueryResults_TextBox.Text += Query4_Bed_UpDown.Value + " beds, ";

                // If there is only 1 Bathroom...
                if (Query4_Bath_UpDown.Value == 1) QueryResults_TextBox.Text += "1 bath, ";
                else QueryResults_TextBox.Text += Query4_Bath_UpDown.Value + " baths, ";

                QueryResults_TextBox.Text += "and " + Query4_MinSqFt_UpDown.Value + " sq. footage";

                // Begin query...
                var HouseQuery = 
                    from H in dekalb.Props.Concat(sycamore.Props)
                    where H is House
                    where H.Forsale != 0
                    where (H as Residental).Bedrooms >= Query4_Bed_UpDown.Value
                    where (H as Residental).Baths >= Query4_Bath_UpDown.Value
                    where (H as Residental).Sqft >= Query4_MinSqFt_UpDown.Value
                    where (H as House).Garage == Query4_Garage_CheckBox.Checked
                    where (H as House).AttachedGarage == Query4_Attached_CheckBox.Checked || (H as House).AttachedGarage == null
                    orderby H.Forsale ascending
                    select H;

                // Check for garage...
                if (Query4_Garage_CheckBox.Checked)
                {
                    if (Query4_Attached_CheckBox.Checked) QueryResults_TextBox.Text += " with a attached garage.";
                    else QueryResults_TextBox.Text += " with a detached garage.";
                }
                else QueryResults_TextBox.Text += " without a garage.";

                QueryResults_TextBox.Text += "\n-------------------------------------------------------------";

                // In the case that there are no properties that fit this query...
                if (HouseQuery.Count() == 0)
                {
                    QueryResults_TextBox.Text += "\nThere are no properties that fit this query!";
                    QueryResults_TextBox.Text += "\n### END OF OUTPUT ###";
                    return;
                }

                // Print results...
                foreach (House h in HouseQuery)
                {
                    QueryResults_TextBox.Text += "\n" + h.ToString("address");
                    QueryResults_TextBox.Text += "\n" + "Owner: ";

                    string ownerName = "No Owner";

                    // Find owner...check both communities...
                    foreach (Person p in dekalb.Residents.Concat(sycamore.Residents))
                    {
                        if (p.Id == h.OwnerID)
                        {
                            ownerName = p.FullName;
                        }
                    }

                    QueryResults_TextBox.Text += ownerName + " | ";

                    if (h.Bedrooms == 1) QueryResults_TextBox.Text += "1 bed, ";
                    else QueryResults_TextBox.Text += h.Bedrooms + " beds, ";

                    if (h.Baths == 1) QueryResults_TextBox.Text += "1 bath, ";
                    else QueryResults_TextBox.Text += h.Baths + " baths, ";

                    QueryResults_TextBox.Text += h.Sqft + "sq.ft";

                    QueryResults_TextBox.Text += "\n" + h.ToString("garageInfo");

                    QueryResults_TextBox.Text += String.Format(" {0: $#,#0}", h.Forsale) + "\n";
                }

            }
            // Otherwise look at just Apartments...
            else
            {
                QueryResults_TextBox.Text = "Apartments with at least ";

                // If there is only 1 Bedroom...
                if (Query4_Bed_UpDown.Value == 1) QueryResults_TextBox.Text += "1 bed, ";
                else QueryResults_TextBox.Text += Query4_Bed_UpDown.Value + " beds, ";

                // If there is only 1 Bathroom...
                if (Query4_Bath_UpDown.Value == 1) QueryResults_TextBox.Text += "1 bath, ";
                else QueryResults_TextBox.Text += Query4_Bath_UpDown.Value + " baths, ";

                QueryResults_TextBox.Text += "and " + Query4_MinSqFt_UpDown.Value + " sq. footage.";
                QueryResults_TextBox.Text += "\n-------------------------------------------------------------";

                // No Garage because of Apartment search...

                // Begin query of Apartments...
                var ApartmentQuery =
                    from A in dekalb.Props.Concat(sycamore.Props)
                    where A is Apartment
                    where A.Forsale != 0
                    where (A as Residental).Bedrooms >= Query4_Bed_UpDown.Value
                    where (A as Residental).Baths >= Query4_Bath_UpDown.Value
                    where (A as Residental).Sqft >= Query4_MinSqFt_UpDown.Value
                    orderby A.Forsale ascending
                    select A;

                // In the case that there are no properties that fit this query...
                if (ApartmentQuery.Count() == 0)
                {
                    QueryResults_TextBox.Text += "\nThere are no properties that fit this query!";
                    QueryResults_TextBox.Text += "\n### END OF OUTPUT ###";
                    return;
                }

                // Print results...
                foreach (Apartment a in ApartmentQuery)
                {
                    QueryResults_TextBox.Text += "\n" + a.ToString("address");
                    QueryResults_TextBox.Text += "\n" + "Owner: ";

                    string ownerName = "No Owner";

                    // Find owner...check both communities...
                    foreach (Person p in dekalb.Residents.Concat(sycamore.Residents))
                    {
                        if (p.Id == a.OwnerID)
                        {
                            ownerName = p.FullName;
                        }
                    }

                    QueryResults_TextBox.Text += ownerName + " | ";

                    if (a.Bedrooms == 1) QueryResults_TextBox.Text += "1 bed, ";
                    else QueryResults_TextBox.Text += a.Bedrooms + " beds, ";

                    if (a.Baths == 1) QueryResults_TextBox.Text += "1 bath, ";
                    else QueryResults_TextBox.Text += a.Baths + " baths, ";

                    QueryResults_TextBox.Text += a.Sqft + "sq.ft";

                    QueryResults_TextBox.Text += String.Format(" {0: $#,#0}", a.Forsale) + "\n";
                }
            }

            QueryResults_TextBox.Text += "\n\n### END OF OUTPUT ###";
        }

        // Get the query for List of Properties Owned by Out-Of-Towners
        private void Query5_Button_Click(object sender, EventArgs e)
        {
            // Print header...
            QueryResults_TextBox.Text = "Properties Owned by Out-Of-Towners";
            QueryResults_TextBox.Text += "\n-------------------------------------------------------------";

            // Does a Prop's owner live within the same Community?
            var OutOfTownQuery =
                from P in dekalb.Props.Concat(sycamore.Props)
                where (dekalb.Props.Contains(P) && dekalb.PropertyOwnedByOutOfTowner(P)) ||
                (sycamore.Props.Contains(P) && sycamore.PropertyOwnedByOutOfTowner(P))
                select P;

            // In the case that there are no properties that fit this query...
            if (OutOfTownQuery.Count() == 0)
            {
                QueryResults_TextBox.Text += "\nThere are no properties that fit this query!";
                QueryResults_TextBox.Text += "\n### END OF OUTPUT ###";
                return;
            }

            // Loop over each Property in the Query...
            foreach (Property p in OutOfTownQuery)
            {
                if (p is Business)
                {
                    QueryResults_TextBox.Text += "\n" + (p as Business).ToString("address");

                    string ownerName = "No Owner";

                    // Find owner...check both communities...
                    foreach (Person person in dekalb.Residents.Concat(sycamore.Residents))
                    {
                        if (person.Id == p.OwnerID)
                        {
                            ownerName = person.FullName;
                        }
                    }

                    QueryResults_TextBox.Text += "\nOwner: " + ownerName + " | ";
                    QueryResults_TextBox.Text += String.Format(" {0: $#,#0}", p.Forsale);

                    QueryResults_TextBox.Text += "\n" + (p as Business).ToString("storeInfo") + "\n";
                }
                // I don't believe this is necessary for our data set... but just in case...
                else
                {
                    QueryResults_TextBox.Text += "\n" + p.StreetAddr + " " + p.City + ", " + p.State + ", " + p.Zip;

                    string ownerName = "No Owner";

                    // Find owner...check both communities...
                    foreach (Person person in dekalb.Residents.Concat(sycamore.Residents))
                    {
                        if (person.Id == p.OwnerID)
                        {
                            ownerName = person.FullName;
                        }
                    }

                    QueryResults_TextBox.Text += "\nOwner: " + ownerName + " | ";
                    QueryResults_TextBox.Text += String.Format(" {0: $#,#0}", p.Forsale) + "\n";
                }
            }

            QueryResults_TextBox.Text += "\n### END OF OUTPUT ###";
        }
    }
}
