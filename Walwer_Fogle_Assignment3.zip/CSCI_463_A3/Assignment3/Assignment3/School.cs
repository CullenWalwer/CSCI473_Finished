﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//***************************************************************************
//
//  Dylan Fogle (z1867886) and Cullen Walwer (z1839148)
//  CSCI 473/504 - Section 1
//
//***************************************************************************

namespace Assignment3
{
    class School : Property
    {
        public enum SchoolType
        {
            Elementary,
            HighSchool,
            CommunityCollege,
            University
        }

        private string name;
        private readonly SchoolType type;
        private readonly string yearEstablished;
        private uint enrolled;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public SchoolType Type
        {
            get { return type; }

        }

        public string YearEstablished
        {
            get { return yearEstablished; }
            //set { yearEstablished = value; }
        }

        public uint Enrolled
        {
            get { return enrolled; }
            set { enrolled = value; }
        }

        public School(params string[] data) : base(data)
        {
            // Because of how the indexes can be messed up with the 3 word long street names,
            // we need to calculate the index for the school name...

            int i = 11;

            if (streetAddr.Split().Length == 4) i = 12;

            int adjust = data.Length - 2;
            for (; i < adjust; i++)
            {
                name += data[i] + " ";
            }

            string schoolType = name.Trim().Split().Last();
            // Have to get name and type separately...
            if (schoolType == "School")
            {
                // Either High School or Elementary School...
                if (name.Split().Contains("High"))
                {
                    type = SchoolType.HighSchool;
                }
                else
                {
                    type = SchoolType.Elementary;
                }
            }
            else if (schoolType == "College")
            {
                type = SchoolType.CommunityCollege;
            }
            else
            {
                type = SchoolType.University;
            }
            //type = (SchoolType)Convert.ToInt32(data[i]);

            yearEstablished = data[i];

            i += 1;
            enrolled = Convert.ToUInt32(data[i]);
        }

        public override string ToString()
        {
            return name.ToString() + " is a " + (SchoolType)type + ", at " + streetAddr;
        }

        public override string ToString(string key)
        {
            if (key == "NAME")
            {
                return name.ToString();
            }
            else if (key == "address")
            {
                return StreetAddr + " " + City + ", " + State + " " + Zip;
            }
            else if (key == "schoolInfo"){
                return Name + ", established in " + YearEstablished;
            }
            return this.ToString();
        }
    }
}
