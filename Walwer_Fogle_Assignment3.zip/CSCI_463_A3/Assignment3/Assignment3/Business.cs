﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//***************************************************************************
//
//  Dylan Fogle (z1867886) and Cullen Walwer (z1839148)
//  CSCI 473/504 - Section 1
//
//***************************************************************************

namespace Assignment3
{
    class Business : Property
    {
        public enum BusinessType
        {
            Grocery,
            Bank,
            Repair,
            FastFood,
            DepartmentStore
        }

        private string name;
        private readonly BusinessType type;
        private readonly string yearEstablished;
        private uint activeRecruitment;

        //properties
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public BusinessType Type
        {
            get { return type; }
        }

        public string YearEstablished
        {
            get { return yearEstablished; }
        }

        public uint ActiveRecruitment
        {
            get { return activeRecruitment; }
            set { activeRecruitment = value; }
        }
        public Business(params string[] data) : base(data)
        {
            int i = 11;
            int adjust = data.Length - 3;
            for (; i < adjust; i++)
            {
                name += data[i] + " ";
            }

            type = (BusinessType)Convert.ToInt32(data[i]);

            i += 1;
            yearEstablished = data[i];

            i += 1;
            activeRecruitment = Convert.ToUInt32(data[i]);
        }

        public override string ToString()
        {
            return name.ToString();
        }

        //Tostring for output on form 
        public override string ToString(uint distance, string ownerName)
        {
            StringBuilder sb = new StringBuilder("");
            return string.Format("{0} {1}, {2} {3}\nOwner: {4} |  {5} units away, with {6} open positions\n" +
                "{7}, a {8} type of business, established in {9}\n",
                StreetAddr, City, State, Zip, ownerName, distance.ToString(), ActiveRecruitment, Name, Type, YearEstablished);
        }

        // Additional toString method...
        public override string ToString(string key)
        {
            if (key == "address")
            {
                return (StreetAddr + " " + City + ", " + State + ", " + Zip);
            }
            else if (key == "storeInfo")
            {
                return Name.Trim() + ", a " + (BusinessType)Type + " type of business, established in " + YearEstablished;
            }
            else return ToString();
        }
    }
}
