﻿
namespace Assignment3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.QueryResults_TextBox = new System.Windows.Forms.RichTextBox();
            this.QueryResults_Label = new System.Windows.Forms.Label();
            this.Query1_GroupBox = new System.Windows.Forms.GroupBox();
            this.Query1_Button = new System.Windows.Forms.Button();
            this.Query1_MinPrice_Label = new System.Windows.Forms.Label();
            this.Query1_MaxPrice_Label = new System.Windows.Forms.Label();
            this.Query1_MaxPrice_TrackBar = new System.Windows.Forms.TrackBar();
            this.Query1_MinPrice_TrackBar = new System.Windows.Forms.TrackBar();
            this.Query1_School_CheckBox = new System.Windows.Forms.CheckBox();
            this.Query1_Business_CheckBox = new System.Windows.Forms.CheckBox();
            this.Query1_Residential_CheckBox = new System.Windows.Forms.CheckBox();
            this.Query2_GroupBox = new System.Windows.Forms.GroupBox();
            this.Query2_Button = new System.Windows.Forms.Button();
            this.Query2_Distance_UpDown = new System.Windows.Forms.NumericUpDown();
            this.Query2_Distance_Label = new System.Windows.Forms.Label();
            this.Query2_School_ComboBox = new System.Windows.Forms.ComboBox();
            this.Query2_School_Label = new System.Windows.Forms.Label();
            this.Query3_GroupBox = new System.Windows.Forms.GroupBox();
            this.Query3_Button = new System.Windows.Forms.Button();
            this.Query3_ForSaleResidence_ComboBox = new System.Windows.Forms.ComboBox();
            this.Query3_Distance_UpDown = new System.Windows.Forms.NumericUpDown();
            this.Query3_ForSaleResidence_Label = new System.Windows.Forms.Label();
            this.Query3_Distance_Label = new System.Windows.Forms.Label();
            this.Query4_GroupBox = new System.Windows.Forms.GroupBox();
            this.Query4_Attached_CheckBox = new System.Windows.Forms.CheckBox();
            this.Query4_MinSqFt_UpDown = new System.Windows.Forms.NumericUpDown();
            this.Query4_Bath_UpDown = new System.Windows.Forms.NumericUpDown();
            this.Query4_Bed_UpDown = new System.Windows.Forms.NumericUpDown();
            this.Query4_Button = new System.Windows.Forms.Button();
            this.Query4_Garage_CheckBox = new System.Windows.Forms.CheckBox();
            this.Query4_MinSqFt_Label = new System.Windows.Forms.Label();
            this.Query4_Bath_Label = new System.Windows.Forms.Label();
            this.Query4_Bed_Label = new System.Windows.Forms.Label();
            this.Query4_Apartment_CheckBox = new System.Windows.Forms.CheckBox();
            this.Query4_House_CheckBox = new System.Windows.Forms.CheckBox();
            this.Query5_GroupBox = new System.Windows.Forms.GroupBox();
            this.Query5_Button = new System.Windows.Forms.Button();
            this.Query1_GroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Query1_MaxPrice_TrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Query1_MinPrice_TrackBar)).BeginInit();
            this.Query2_GroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Query2_Distance_UpDown)).BeginInit();
            this.Query3_GroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Query3_Distance_UpDown)).BeginInit();
            this.Query4_GroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Query4_MinSqFt_UpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Query4_Bath_UpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Query4_Bed_UpDown)).BeginInit();
            this.Query5_GroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // QueryResults_TextBox
            // 
            this.QueryResults_TextBox.BackColor = System.Drawing.Color.White;
            this.QueryResults_TextBox.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.QueryResults_TextBox.Location = new System.Drawing.Point(477, 33);
            this.QueryResults_TextBox.Name = "QueryResults_TextBox";
            this.QueryResults_TextBox.ReadOnly = true;
            this.QueryResults_TextBox.Size = new System.Drawing.Size(500, 517);
            this.QueryResults_TextBox.TabIndex = 0;
            this.QueryResults_TextBox.Text = "";
            // 
            // QueryResults_Label
            // 
            this.QueryResults_Label.AutoSize = true;
            this.QueryResults_Label.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.QueryResults_Label.Location = new System.Drawing.Point(477, 9);
            this.QueryResults_Label.Name = "QueryResults_Label";
            this.QueryResults_Label.Size = new System.Drawing.Size(115, 21);
            this.QueryResults_Label.TabIndex = 1;
            this.QueryResults_Label.Text = "Query Results";
            // 
            // Query1_GroupBox
            // 
            this.Query1_GroupBox.Controls.Add(this.Query1_Button);
            this.Query1_GroupBox.Controls.Add(this.Query1_MinPrice_Label);
            this.Query1_GroupBox.Controls.Add(this.Query1_MaxPrice_Label);
            this.Query1_GroupBox.Controls.Add(this.Query1_MaxPrice_TrackBar);
            this.Query1_GroupBox.Controls.Add(this.Query1_MinPrice_TrackBar);
            this.Query1_GroupBox.Controls.Add(this.Query1_School_CheckBox);
            this.Query1_GroupBox.Controls.Add(this.Query1_Business_CheckBox);
            this.Query1_GroupBox.Controls.Add(this.Query1_Residential_CheckBox);
            this.Query1_GroupBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Query1_GroupBox.Location = new System.Drawing.Point(12, 9);
            this.Query1_GroupBox.Name = "Query1_GroupBox";
            this.Query1_GroupBox.Size = new System.Drawing.Size(459, 159);
            this.Query1_GroupBox.TabIndex = 2;
            this.Query1_GroupBox.TabStop = false;
            this.Query1_GroupBox.Text = "For Sale Properties Within Price Range";
            // 
            // Query1_Button
            // 
            this.Query1_Button.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query1_Button.Location = new System.Drawing.Point(365, 49);
            this.Query1_Button.Name = "Query1_Button";
            this.Query1_Button.Size = new System.Drawing.Size(75, 23);
            this.Query1_Button.TabIndex = 13;
            this.Query1_Button.Text = "Query";
            this.Query1_Button.UseVisualStyleBackColor = true;
            this.Query1_Button.Click += new System.EventHandler(this.Query1_Button_Click);
            // 
            // Query1_MinPrice_Label
            // 
            this.Query1_MinPrice_Label.AutoSize = true;
            this.Query1_MinPrice_Label.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query1_MinPrice_Label.Location = new System.Drawing.Point(100, 24);
            this.Query1_MinPrice_Label.Name = "Query1_MinPrice_Label";
            this.Query1_MinPrice_Label.Size = new System.Drawing.Size(62, 17);
            this.Query1_MinPrice_Label.TabIndex = 12;
            this.Query1_MinPrice_Label.Text = "Min Price";
            // 
            // Query1_MaxPrice_Label
            // 
            this.Query1_MaxPrice_Label.AutoSize = true;
            this.Query1_MaxPrice_Label.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query1_MaxPrice_Label.Location = new System.Drawing.Point(100, 93);
            this.Query1_MaxPrice_Label.Name = "Query1_MaxPrice_Label";
            this.Query1_MaxPrice_Label.Size = new System.Drawing.Size(65, 17);
            this.Query1_MaxPrice_Label.TabIndex = 11;
            this.Query1_MaxPrice_Label.Text = "Max Price";
            // 
            // Query1_MaxPrice_TrackBar
            // 
            this.Query1_MaxPrice_TrackBar.Location = new System.Drawing.Point(100, 117);
            this.Query1_MaxPrice_TrackBar.Maximum = 350000;
            this.Query1_MaxPrice_TrackBar.Name = "Query1_MaxPrice_TrackBar";
            this.Query1_MaxPrice_TrackBar.Size = new System.Drawing.Size(146, 45);
            this.Query1_MaxPrice_TrackBar.TabIndex = 10;
            this.Query1_MaxPrice_TrackBar.TickFrequency = 25000;
            this.Query1_MaxPrice_TrackBar.ValueChanged += new System.EventHandler(this.Query1_MaxPrice_TrackBar_ValueChanged);
            // 
            // Query1_MinPrice_TrackBar
            // 
            this.Query1_MinPrice_TrackBar.Location = new System.Drawing.Point(100, 51);
            this.Query1_MinPrice_TrackBar.Maximum = 350000;
            this.Query1_MinPrice_TrackBar.Name = "Query1_MinPrice_TrackBar";
            this.Query1_MinPrice_TrackBar.Size = new System.Drawing.Size(146, 45);
            this.Query1_MinPrice_TrackBar.TabIndex = 9;
            this.Query1_MinPrice_TrackBar.TickFrequency = 25000;
            this.Query1_MinPrice_TrackBar.ValueChanged += new System.EventHandler(this.Query1_MinPrice_TrackBar_ValueChanged);
            // 
            // Query1_School_CheckBox
            // 
            this.Query1_School_CheckBox.AutoSize = true;
            this.Query1_School_CheckBox.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query1_School_CheckBox.Location = new System.Drawing.Point(7, 78);
            this.Query1_School_CheckBox.Name = "Query1_School_CheckBox";
            this.Query1_School_CheckBox.Size = new System.Drawing.Size(66, 21);
            this.Query1_School_CheckBox.TabIndex = 8;
            this.Query1_School_CheckBox.Text = "School";
            this.Query1_School_CheckBox.UseVisualStyleBackColor = true;
            // 
            // Query1_Business_CheckBox
            // 
            this.Query1_Business_CheckBox.AutoSize = true;
            this.Query1_Business_CheckBox.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query1_Business_CheckBox.Location = new System.Drawing.Point(7, 51);
            this.Query1_Business_CheckBox.Name = "Query1_Business_CheckBox";
            this.Query1_Business_CheckBox.Size = new System.Drawing.Size(76, 21);
            this.Query1_Business_CheckBox.TabIndex = 7;
            this.Query1_Business_CheckBox.Text = "Business";
            this.Query1_Business_CheckBox.UseVisualStyleBackColor = true;
            // 
            // Query1_Residential_CheckBox
            // 
            this.Query1_Residential_CheckBox.AutoSize = true;
            this.Query1_Residential_CheckBox.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query1_Residential_CheckBox.Location = new System.Drawing.Point(7, 24);
            this.Query1_Residential_CheckBox.Name = "Query1_Residential_CheckBox";
            this.Query1_Residential_CheckBox.Size = new System.Drawing.Size(90, 21);
            this.Query1_Residential_CheckBox.TabIndex = 0;
            this.Query1_Residential_CheckBox.Text = "Residential";
            this.Query1_Residential_CheckBox.UseVisualStyleBackColor = true;
            // 
            // Query2_GroupBox
            // 
            this.Query2_GroupBox.Controls.Add(this.Query2_Button);
            this.Query2_GroupBox.Controls.Add(this.Query2_Distance_UpDown);
            this.Query2_GroupBox.Controls.Add(this.Query2_Distance_Label);
            this.Query2_GroupBox.Controls.Add(this.Query2_School_ComboBox);
            this.Query2_GroupBox.Controls.Add(this.Query2_School_Label);
            this.Query2_GroupBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Query2_GroupBox.Location = new System.Drawing.Point(12, 177);
            this.Query2_GroupBox.Name = "Query2_GroupBox";
            this.Query2_GroupBox.Size = new System.Drawing.Size(459, 95);
            this.Query2_GroupBox.TabIndex = 3;
            this.Query2_GroupBox.TabStop = false;
            this.Query2_GroupBox.Text = "For Sale Residences Within Range of a School";
            // 
            // Query2_Button
            // 
            this.Query2_Button.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query2_Button.Location = new System.Drawing.Point(365, 46);
            this.Query2_Button.Name = "Query2_Button";
            this.Query2_Button.Size = new System.Drawing.Size(75, 23);
            this.Query2_Button.TabIndex = 14;
            this.Query2_Button.Text = "Query";
            this.Query2_Button.UseVisualStyleBackColor = true;
            this.Query2_Button.Click += new System.EventHandler(this.Query2_Button_Click);
            // 
            // Query2_Distance_UpDown
            // 
            this.Query2_Distance_UpDown.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query2_Distance_UpDown.Increment = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.Query2_Distance_UpDown.Location = new System.Drawing.Point(211, 47);
            this.Query2_Distance_UpDown.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.Query2_Distance_UpDown.Name = "Query2_Distance_UpDown";
            this.Query2_Distance_UpDown.Size = new System.Drawing.Size(120, 25);
            this.Query2_Distance_UpDown.TabIndex = 17;
            // 
            // Query2_Distance_Label
            // 
            this.Query2_Distance_Label.AutoSize = true;
            this.Query2_Distance_Label.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query2_Distance_Label.Location = new System.Drawing.Point(211, 25);
            this.Query2_Distance_Label.Name = "Query2_Distance_Label";
            this.Query2_Distance_Label.Size = new System.Drawing.Size(57, 17);
            this.Query2_Distance_Label.TabIndex = 16;
            this.Query2_Distance_Label.Text = "Distance";
            // 
            // Query2_School_ComboBox
            // 
            this.Query2_School_ComboBox.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query2_School_ComboBox.FormattingEnabled = true;
            this.Query2_School_ComboBox.Location = new System.Drawing.Point(8, 46);
            this.Query2_School_ComboBox.Name = "Query2_School_ComboBox";
            this.Query2_School_ComboBox.Size = new System.Drawing.Size(186, 25);
            this.Query2_School_ComboBox.TabIndex = 15;
            this.Query2_School_ComboBox.DropDown += new System.EventHandler(this.Query2_School_ComboBox_DropDown);
            // 
            // Query2_School_Label
            // 
            this.Query2_School_Label.AutoSize = true;
            this.Query2_School_Label.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query2_School_Label.Location = new System.Drawing.Point(8, 25);
            this.Query2_School_Label.Name = "Query2_School_Label";
            this.Query2_School_Label.Size = new System.Drawing.Size(47, 17);
            this.Query2_School_Label.TabIndex = 14;
            this.Query2_School_Label.Text = "School";
            // 
            // Query3_GroupBox
            // 
            this.Query3_GroupBox.Controls.Add(this.Query3_Button);
            this.Query3_GroupBox.Controls.Add(this.Query3_ForSaleResidence_ComboBox);
            this.Query3_GroupBox.Controls.Add(this.Query3_Distance_UpDown);
            this.Query3_GroupBox.Controls.Add(this.Query3_ForSaleResidence_Label);
            this.Query3_GroupBox.Controls.Add(this.Query3_Distance_Label);
            this.Query3_GroupBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Query3_GroupBox.Location = new System.Drawing.Point(12, 278);
            this.Query3_GroupBox.Name = "Query3_GroupBox";
            this.Query3_GroupBox.Size = new System.Drawing.Size(459, 95);
            this.Query3_GroupBox.TabIndex = 4;
            this.Query3_GroupBox.TabStop = false;
            this.Query3_GroupBox.Text = "Hiring Business(es) Within Range of For Sale Residence";
            // 
            // Query3_Button
            // 
            this.Query3_Button.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query3_Button.Location = new System.Drawing.Point(365, 44);
            this.Query3_Button.Name = "Query3_Button";
            this.Query3_Button.Size = new System.Drawing.Size(75, 23);
            this.Query3_Button.TabIndex = 18;
            this.Query3_Button.Text = "Query";
            this.Query3_Button.UseVisualStyleBackColor = true;
            this.Query3_Button.Click += new System.EventHandler(this.Query3_Button_Click);
            // 
            // Query3_ForSaleResidence_ComboBox
            // 
            this.Query3_ForSaleResidence_ComboBox.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query3_ForSaleResidence_ComboBox.FormattingEnabled = true;
            this.Query3_ForSaleResidence_ComboBox.Location = new System.Drawing.Point(8, 44);
            this.Query3_ForSaleResidence_ComboBox.Name = "Query3_ForSaleResidence_ComboBox";
            this.Query3_ForSaleResidence_ComboBox.Size = new System.Drawing.Size(186, 25);
            this.Query3_ForSaleResidence_ComboBox.TabIndex = 20;
            this.Query3_ForSaleResidence_ComboBox.DropDown += new System.EventHandler(this.Query3_ForSaleResidence_ComboBox_DropDown);
            // 
            // Query3_Distance_UpDown
            // 
            this.Query3_Distance_UpDown.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query3_Distance_UpDown.Increment = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.Query3_Distance_UpDown.Location = new System.Drawing.Point(211, 45);
            this.Query3_Distance_UpDown.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.Query3_Distance_UpDown.Name = "Query3_Distance_UpDown";
            this.Query3_Distance_UpDown.Size = new System.Drawing.Size(120, 25);
            this.Query3_Distance_UpDown.TabIndex = 22;
            // 
            // Query3_ForSaleResidence_Label
            // 
            this.Query3_ForSaleResidence_Label.AutoSize = true;
            this.Query3_ForSaleResidence_Label.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query3_ForSaleResidence_Label.Location = new System.Drawing.Point(8, 23);
            this.Query3_ForSaleResidence_Label.Name = "Query3_ForSaleResidence_Label";
            this.Query3_ForSaleResidence_Label.Size = new System.Drawing.Size(119, 17);
            this.Query3_ForSaleResidence_Label.TabIndex = 19;
            this.Query3_ForSaleResidence_Label.Text = "For-Sale Residence";
            // 
            // Query3_Distance_Label
            // 
            this.Query3_Distance_Label.AutoSize = true;
            this.Query3_Distance_Label.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query3_Distance_Label.Location = new System.Drawing.Point(211, 23);
            this.Query3_Distance_Label.Name = "Query3_Distance_Label";
            this.Query3_Distance_Label.Size = new System.Drawing.Size(57, 17);
            this.Query3_Distance_Label.TabIndex = 21;
            this.Query3_Distance_Label.Text = "Distance";
            // 
            // Query4_GroupBox
            // 
            this.Query4_GroupBox.Controls.Add(this.Query4_Attached_CheckBox);
            this.Query4_GroupBox.Controls.Add(this.Query4_MinSqFt_UpDown);
            this.Query4_GroupBox.Controls.Add(this.Query4_Bath_UpDown);
            this.Query4_GroupBox.Controls.Add(this.Query4_Bed_UpDown);
            this.Query4_GroupBox.Controls.Add(this.Query4_Button);
            this.Query4_GroupBox.Controls.Add(this.Query4_Garage_CheckBox);
            this.Query4_GroupBox.Controls.Add(this.Query4_MinSqFt_Label);
            this.Query4_GroupBox.Controls.Add(this.Query4_Bath_Label);
            this.Query4_GroupBox.Controls.Add(this.Query4_Bed_Label);
            this.Query4_GroupBox.Controls.Add(this.Query4_Apartment_CheckBox);
            this.Query4_GroupBox.Controls.Add(this.Query4_House_CheckBox);
            this.Query4_GroupBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Query4_GroupBox.Location = new System.Drawing.Point(12, 379);
            this.Query4_GroupBox.Name = "Query4_GroupBox";
            this.Query4_GroupBox.Size = new System.Drawing.Size(459, 95);
            this.Query4_GroupBox.TabIndex = 5;
            this.Query4_GroupBox.TabStop = false;
            this.Query4_GroupBox.Text = "Specific Residence Parameters";
            // 
            // Query4_Attached_CheckBox
            // 
            this.Query4_Attached_CheckBox.AutoSize = true;
            this.Query4_Attached_CheckBox.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query4_Attached_CheckBox.Location = new System.Drawing.Point(285, 55);
            this.Query4_Attached_CheckBox.Name = "Query4_Attached_CheckBox";
            this.Query4_Attached_CheckBox.Size = new System.Drawing.Size(84, 21);
            this.Query4_Attached_CheckBox.TabIndex = 28;
            this.Query4_Attached_CheckBox.Text = "Attached?";
            this.Query4_Attached_CheckBox.UseVisualStyleBackColor = true;
            this.Query4_Attached_CheckBox.Visible = false;
            // 
            // Query4_MinSqFt_UpDown
            // 
            this.Query4_MinSqFt_UpDown.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query4_MinSqFt_UpDown.Increment = new decimal(new int[] {
            250,
            0,
            0,
            0});
            this.Query4_MinSqFt_UpDown.Location = new System.Drawing.Point(202, 54);
            this.Query4_MinSqFt_UpDown.Maximum = new decimal(new int[] {
            6000,
            0,
            0,
            0});
            this.Query4_MinSqFt_UpDown.Minimum = new decimal(new int[] {
            1200,
            0,
            0,
            0});
            this.Query4_MinSqFt_UpDown.Name = "Query4_MinSqFt_UpDown";
            this.Query4_MinSqFt_UpDown.Size = new System.Drawing.Size(65, 25);
            this.Query4_MinSqFt_UpDown.TabIndex = 27;
            this.Query4_MinSqFt_UpDown.Value = new decimal(new int[] {
            1200,
            0,
            0,
            0});
            // 
            // Query4_Bath_UpDown
            // 
            this.Query4_Bath_UpDown.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query4_Bath_UpDown.Location = new System.Drawing.Point(149, 54);
            this.Query4_Bath_UpDown.Maximum = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.Query4_Bath_UpDown.Name = "Query4_Bath_UpDown";
            this.Query4_Bath_UpDown.Size = new System.Drawing.Size(30, 25);
            this.Query4_Bath_UpDown.TabIndex = 26;
            // 
            // Query4_Bed_UpDown
            // 
            this.Query4_Bed_UpDown.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query4_Bed_UpDown.Location = new System.Drawing.Point(100, 54);
            this.Query4_Bed_UpDown.Maximum = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.Query4_Bed_UpDown.Name = "Query4_Bed_UpDown";
            this.Query4_Bed_UpDown.Size = new System.Drawing.Size(30, 25);
            this.Query4_Bed_UpDown.TabIndex = 25;
            // 
            // Query4_Button
            // 
            this.Query4_Button.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query4_Button.Location = new System.Drawing.Point(365, 22);
            this.Query4_Button.Name = "Query4_Button";
            this.Query4_Button.Size = new System.Drawing.Size(75, 23);
            this.Query4_Button.TabIndex = 24;
            this.Query4_Button.Text = "Query";
            this.Query4_Button.UseVisualStyleBackColor = true;
            this.Query4_Button.Click += new System.EventHandler(this.Query4_Button_Click);
            // 
            // Query4_Garage_CheckBox
            // 
            this.Query4_Garage_CheckBox.AutoSize = true;
            this.Query4_Garage_CheckBox.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query4_Garage_CheckBox.Location = new System.Drawing.Point(285, 28);
            this.Query4_Garage_CheckBox.Name = "Query4_Garage_CheckBox";
            this.Query4_Garage_CheckBox.Size = new System.Drawing.Size(70, 21);
            this.Query4_Garage_CheckBox.TabIndex = 23;
            this.Query4_Garage_CheckBox.Text = "Garage";
            this.Query4_Garage_CheckBox.UseVisualStyleBackColor = true;
            this.Query4_Garage_CheckBox.CheckedChanged += new System.EventHandler(this.Query4_Garage_CheckBox_CheckedChanged);
            // 
            // Query4_MinSqFt_Label
            // 
            this.Query4_MinSqFt_Label.AutoSize = true;
            this.Query4_MinSqFt_Label.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query4_MinSqFt_Label.Location = new System.Drawing.Point(202, 29);
            this.Query4_MinSqFt_Label.Name = "Query4_MinSqFt_Label";
            this.Query4_MinSqFt_Label.Size = new System.Drawing.Size(65, 17);
            this.Query4_MinSqFt_Label.TabIndex = 22;
            this.Query4_MinSqFt_Label.Text = "Min Sq.Ft.";
            // 
            // Query4_Bath_Label
            // 
            this.Query4_Bath_Label.AutoSize = true;
            this.Query4_Bath_Label.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query4_Bath_Label.Location = new System.Drawing.Point(149, 29);
            this.Query4_Bath_Label.Name = "Query4_Bath_Label";
            this.Query4_Bath_Label.Size = new System.Drawing.Size(33, 17);
            this.Query4_Bath_Label.TabIndex = 21;
            this.Query4_Bath_Label.Text = "Bath";
            // 
            // Query4_Bed_Label
            // 
            this.Query4_Bed_Label.AutoSize = true;
            this.Query4_Bed_Label.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query4_Bed_Label.Location = new System.Drawing.Point(100, 29);
            this.Query4_Bed_Label.Name = "Query4_Bed_Label";
            this.Query4_Bed_Label.Size = new System.Drawing.Size(30, 17);
            this.Query4_Bed_Label.TabIndex = 20;
            this.Query4_Bed_Label.Text = "Bed";
            // 
            // Query4_Apartment_CheckBox
            // 
            this.Query4_Apartment_CheckBox.AutoSize = true;
            this.Query4_Apartment_CheckBox.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query4_Apartment_CheckBox.Location = new System.Drawing.Point(8, 55);
            this.Query4_Apartment_CheckBox.Name = "Query4_Apartment_CheckBox";
            this.Query4_Apartment_CheckBox.Size = new System.Drawing.Size(88, 21);
            this.Query4_Apartment_CheckBox.TabIndex = 10;
            this.Query4_Apartment_CheckBox.Text = "Apartment";
            this.Query4_Apartment_CheckBox.UseVisualStyleBackColor = true;
            this.Query4_Apartment_CheckBox.CheckedChanged += new System.EventHandler(this.Query4_Apartment_CheckBox_CheckedChanged);
            // 
            // Query4_House_CheckBox
            // 
            this.Query4_House_CheckBox.AutoSize = true;
            this.Query4_House_CheckBox.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query4_House_CheckBox.Location = new System.Drawing.Point(8, 28);
            this.Query4_House_CheckBox.Name = "Query4_House_CheckBox";
            this.Query4_House_CheckBox.Size = new System.Drawing.Size(64, 21);
            this.Query4_House_CheckBox.TabIndex = 9;
            this.Query4_House_CheckBox.Text = "House";
            this.Query4_House_CheckBox.UseVisualStyleBackColor = true;
            // 
            // Query5_GroupBox
            // 
            this.Query5_GroupBox.Controls.Add(this.Query5_Button);
            this.Query5_GroupBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Query5_GroupBox.Location = new System.Drawing.Point(12, 480);
            this.Query5_GroupBox.Name = "Query5_GroupBox";
            this.Query5_GroupBox.Size = new System.Drawing.Size(459, 70);
            this.Query5_GroupBox.TabIndex = 6;
            this.Query5_GroupBox.TabStop = false;
            this.Query5_GroupBox.Text = "List of Properties Owned By Out-Of-Towners";
            // 
            // Query5_Button
            // 
            this.Query5_Button.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Query5_Button.Location = new System.Drawing.Point(365, 28);
            this.Query5_Button.Name = "Query5_Button";
            this.Query5_Button.Size = new System.Drawing.Size(75, 23);
            this.Query5_Button.TabIndex = 25;
            this.Query5_Button.Text = "Query";
            this.Query5_Button.UseVisualStyleBackColor = true;
            this.Query5_Button.Click += new System.EventHandler(this.Query5_Button_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(989, 561);
            this.Controls.Add(this.Query5_GroupBox);
            this.Controls.Add(this.Query4_GroupBox);
            this.Controls.Add(this.Query3_GroupBox);
            this.Controls.Add(this.Query2_GroupBox);
            this.Controls.Add(this.Query1_GroupBox);
            this.Controls.Add(this.QueryResults_Label);
            this.Controls.Add(this.QueryResults_TextBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Query1_GroupBox.ResumeLayout(false);
            this.Query1_GroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Query1_MaxPrice_TrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Query1_MinPrice_TrackBar)).EndInit();
            this.Query2_GroupBox.ResumeLayout(false);
            this.Query2_GroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Query2_Distance_UpDown)).EndInit();
            this.Query3_GroupBox.ResumeLayout(false);
            this.Query3_GroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Query3_Distance_UpDown)).EndInit();
            this.Query4_GroupBox.ResumeLayout(false);
            this.Query4_GroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Query4_MinSqFt_UpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Query4_Bath_UpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Query4_Bed_UpDown)).EndInit();
            this.Query5_GroupBox.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox QueryResults_TextBox;
        private System.Windows.Forms.Label QueryResults_Label;
        private System.Windows.Forms.GroupBox Query1_GroupBox;
        private System.Windows.Forms.CheckBox Query1_School_CheckBox;
        private System.Windows.Forms.CheckBox Query1_Business_CheckBox;
        private System.Windows.Forms.CheckBox Query1_Residential_CheckBox;
        private System.Windows.Forms.GroupBox Query2_GroupBox;
        private System.Windows.Forms.GroupBox Query3_GroupBox;
        private System.Windows.Forms.GroupBox Query4_GroupBox;
        private System.Windows.Forms.GroupBox Query5_GroupBox;
        private System.Windows.Forms.TrackBar Query1_MinPrice_TrackBar;
        private System.Windows.Forms.Button Query1_Button;
        private System.Windows.Forms.Label Query1_MinPrice_Label;
        private System.Windows.Forms.Label Query1_MaxPrice_Label;
        private System.Windows.Forms.TrackBar Query1_MaxPrice_TrackBar;
        private System.Windows.Forms.Button Query2_Button;
        private System.Windows.Forms.NumericUpDown Query2_Distance_UpDown;
        private System.Windows.Forms.Label Query2_Distance_Label;
        private System.Windows.Forms.ComboBox Query2_School_ComboBox;
        private System.Windows.Forms.Label Query2_School_Label;
        private System.Windows.Forms.Button Query3_Button;
        private System.Windows.Forms.ComboBox Query3_ForSaleResidence_ComboBox;
        private System.Windows.Forms.NumericUpDown Query3_Distance_UpDown;
        private System.Windows.Forms.Label Query3_ForSaleResidence_Label;
        private System.Windows.Forms.Label Query3_Distance_Label;
        private System.Windows.Forms.Label Query4_Bed_Label;
        private System.Windows.Forms.CheckBox Query4_Apartment_CheckBox;
        private System.Windows.Forms.CheckBox Query4_House_CheckBox;
        private System.Windows.Forms.Button Query4_Button;
        private System.Windows.Forms.CheckBox Query4_Garage_CheckBox;
        private System.Windows.Forms.Label Query4_MinSqFt_Label;
        private System.Windows.Forms.Label Query4_Bath_Label;
        private System.Windows.Forms.NumericUpDown Query4_Bed_UpDown;
        private System.Windows.Forms.NumericUpDown Query4_Bath_UpDown;
        private System.Windows.Forms.NumericUpDown Query4_MinSqFt_UpDown;
        private System.Windows.Forms.Button Query5_Button;
        private System.Windows.Forms.CheckBox Query4_Attached_CheckBox;
    }
}

