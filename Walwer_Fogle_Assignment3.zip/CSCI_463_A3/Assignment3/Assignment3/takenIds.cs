﻿using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using System.Collections;
using System.Linq;

//***************************************************************************
//
//  Dylan Fogle (z1867886) and Cullen Walwer (z1839148)
//  CSCI 473/504 - Section 1
//
//***************************************************************************

namespace Assignment3
{
    static class takenIds
    {
        public static List<uint> ids = new List<uint>(); // Keep track of available ids.
    }
}
