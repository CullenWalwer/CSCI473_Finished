﻿using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using System.Collections;
using System.Linq;

//***************************************************************************
//
//  Dylan Fogle (z1867886) and Cullen Walwer (z1839148)
//  CSCI 473/504 - Section 1
//
//***************************************************************************

namespace Assignment3
{
    class House : Residental
    {
        //Attributes
        private bool garage;
        private Nullable<bool> attachedGarage;
        private uint floors;

        //properties
        public bool Garage
        {
            set
            {
                garage = value;

                //if no garage attachedGarage = null 
                if (!garage)
                {
                    attachedGarage = null;
                }
            }
            get { return garage; }
        }
        public Nullable<bool> AttachedGarage
        {
            get { return attachedGarage; }
            //may only be set if a garage has value
            set { if (attachedGarage.HasValue) { attachedGarage = value; } }
        }
        public uint Floors
        {
            set { floors = value; }
            get { return floors; }
        }

        //default constructor
        public House() : base()
        {
            garage = false;
            attachedGarage = null;
            floors = 1;
        }

        //data constructor
        public House(params string[] data) : base(data)
        {
            if (data.Length <= 14)
            {
                garage = false;
                attachedGarage = null;
                floors = 1;

                return;
            }

            //if has a garage then attachedGarage has value
            if (Convert.ToString(data[14]) == "T")
            {
                garage = true;
                if (Convert.ToString(data[15]) == "T")
                {
                    attachedGarage = true;
                }
                else
                {
                    attachedGarage = false;
                }
            }
            //no garage attachedGarage is null 
            else
            {
                garage = false;
                attachedGarage = null;
            }
            floors = Convert.ToUInt32(data[16]);
        }

        //ToString default
        public override string ToString()
        {
            StringBuilder midString = new StringBuilder(base.ToString());
            if (garage)
            {
                //check for null caracter
                bool garagePosition = attachedGarage ?? false;
                if (garagePosition)
                {
                    midString.Append(String.Format("\n        ... with an attached garage : {0} floors.\n", floors));
                }
                if (!garagePosition)
                {
                    midString.Append(String.Format("\n        ... with a detached garage : {0} floors.\n", floors));
                }
            }
            else
            {
                midString.Append(String.Format("\n        ... with no garage : {0} floors.\n", floors));
            }
            return midString.ToString();
        }

        public override string ToString(uint distance, string name)
        {
            StringBuilder sb = new StringBuilder(base.ToString(distance, name));
            sb.Append(string.Format("Owner: {0} |  {1} beds, {2} bath, {3} sq.ft\n", name, Bedrooms, Baths, Sqft));
            if (garage)
            {
                //check for null caracter
                bool garagePosition = attachedGarage ?? false;
                if (garagePosition)
                {
                    sb.Append(String.Format(" with an attached garage : {0} floors.    {1:C2}", floors, forSale));
                }
                if (!garagePosition)
                {
                    sb.Append(String.Format(" with a detached garage : {0} floors.    {1:C2}", floors, forSale));
                }
            }
            else
            {
                sb.Append(String.Format(" with no garage : {0} floors.    {1:C2}", floors, forSale));
            }
            return sb.ToString();
        }

        //ToString with address option 
        public override string ToString(string key)
        {
            if (key == "out")
            {
                return this.StreetAddr.ToString();
            }
            if (key == "ListBox")
            {
                //if (Forsale)
                if (Forsale == 0)
                {
                    return String.Format("{0, 25} *", StreetAddr);
                }
                else
                {
                    return String.Format("{0, 25}", StreetAddr);
                }
            }
            else if (key == "address")
            {
                return (StreetAddr + " " + City + ", " + State + ", " + Zip);
            }
            else if (key == "garageInfo")
            {
                StringBuilder midString = new StringBuilder();
                if (garage)
                {
                    bool garagePosition = attachedGarage ?? false;
                    if (garagePosition)
                    {
                        midString.Append(String.Format(" with an attached garage : {0} floors.", floors));
                    }
                    if (!garagePosition)
                    {
                        midString.Append(String.Format(" with a detached garage : {0} floors.", floors));
                    }
                }
                else
                {
                    midString.Append(String.Format(" with no garage : {0} floors.", floors));
                }
                return midString.ToString();
            }
            else
            {
                StringBuilder midString = new StringBuilder(base.ToString(key));
                if (garage)
                {
                    bool garagePosition = attachedGarage ?? false;
                    if (garagePosition)
                    {
                        midString.Append(String.Format("\n        ... with an attached garage : {0} floors.\n", floors));
                    }
                    if (!garagePosition)
                    {
                        midString.Append(String.Format("\n        ... with a detached garage : {0} floors.\n", floors));
                    }
                }
                else
                {
                    midString.Append(String.Format("\n        ... with no garage : {0} floors.\n", floors));
                }
                return midString.ToString();
            }
        }

    }
}
