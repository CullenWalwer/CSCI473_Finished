﻿using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using System.Collections;
using System.Linq;

//***************************************************************************
//
//  Dylan Fogle (z1867886) and Cullen Walwer (z1839148)
//  CSCI 473/504 - Section 1
//
//***************************************************************************

namespace WindowsFormsApp1
{
    public class Person : IComparable
    {
        // Private attributes.
        private readonly uint id;
        private string lastName;
        private string firstName;
        private string occupation;
        private readonly DateTime birthday;
        private List<uint> residenceIds;

        // Public Properties for attributes.
        public uint Id
        {
            get { return id; }
        }

        public string LastName
        {
            get { return lastName; }
            set
            {
                // Check that value is string.
                if (!(value is string)) return;

                lastName = value;
            }
        }

        public string FirstName
        {
            get { return firstName; }
            set
            {
                // Check that value is string.
                if (!(value is string)) return;

                firstName = value;
            }
        }

        public string Occupation
        {
            get { return occupation; }
            set
            {
                // Check that value is a string.
                if (!(value is string)) return;

                occupation = value;
            }
        }

        public DateTime Birthday
        {
            get { return birthday; }
        }

        public uint[] ResidenceIds
        {
            get { return residenceIds.ToArray(); }
        }

        public void addResidenceId(uint newResidence)
        {
            residenceIds.Add(newResidence);
        }

        public void removeResidenceId(uint oldResidence)
        {
            residenceIds.Remove(oldResidence);
        }

        // Get-Only full name of the Person.
        public string FullName => lastName + ", " + firstName;

        // Default constructor.
        public Person()
        {
            id = (uint)takenIds.ids.Count;

            while (takenIds.ids.Contains(id)) id = id++;
            takenIds.ids.Add(id);

            lastName = "";
            firstName = "";
            occupation = "";
            birthday = new DateTime();
            residenceIds = new List<uint>();
        }

        // Alternate constructor.
        public Person(params string[] data)
        {
            // ID, LastName, FirstName, Occupation...
            // Check after FirstName whether value is numeric. If it is, skip occupation...
            // After birthday, just take rest of values for residence Ids.

            id = Convert.ToUInt32(data[0]);
            while (takenIds.ids.Contains(id)) id += 1;
            takenIds.ids.Add(id);

            LastName = data[1];
            FirstName = data[2];

            // If value is string, it is occupation.
            if (!UInt32.TryParse(data[3], out _))
            {
                // If this value is string, it is second word of occupation...
                if (!UInt32.TryParse(data[4], out _))
                {
                    Occupation = data[3] + " " + data[4];

                    birthday = new DateTime(Convert.ToInt32(data[5]), Convert.ToInt32(data[6]), Convert.ToInt32(data[7]), 0, 0, 0);

                    // Prepare residence ids.
                    List<uint> residences = new List<uint>();

                    // Travel through rest of data...
                    for (int i = 8; i < data.Length; i++)
                    {
                        residences.Add(Convert.ToUInt32(data[i]));
                    }

                    residenceIds = residences;
                }
                // This is start of birthday...
                else
                {
                    Occupation = data[3];

                    birthday = new DateTime(Convert.ToInt32(data[4]), Convert.ToInt32(data[5]), Convert.ToInt32(data[6]), 0, 0, 0);

                    // Prepare residence ids.
                    List<uint> residences = new List<uint>();

                    // Travel through rest of data...
                    for (int i = 7; i < data.Length; i++)
                    {
                        residences.Add(Convert.ToUInt32(data[i]));
                    }

                    residenceIds = residences;
                }
            }
            // There is no occupation, continue to birthday.
            else
            {
                Occupation = "Jobless";

                birthday = new DateTime(Convert.ToInt32(data[3]), Convert.ToInt32(data[4]), Convert.ToInt32(data[5]), 0, 0, 0);

                // Prepare residence ids.
                List<uint> residences = new List<uint>();

                // Travel through rest of data...
                for(int i = 6; i < data.Length; i++)
                {
                    residences.Add(Convert.ToUInt32(data[i]));
                }

                residenceIds = residences;
            }
        }

        // IComparable interface.
        public int CompareTo(object alpha)
        {
            // Check for null value.
            if (alpha == null) throw new ArgumentNullException();

            Person rightOp = alpha as Person;

            if (rightOp != null) return FullName.CompareTo(rightOp.FullName);
            else throw new ArgumentException("[Person]:CompareTo argument is not a Person!");
        }

        // Overwritten ToString() method.
        public override string ToString()
        {
            int yearsOld = (int)((DateTime.Now - birthday).TotalDays / 365.25);

            return (FullName + ", Age (" + yearsOld + "), Occupation: " + occupation);
        }

        public string ToString(string key)
        {
            if (key.CompareTo("out") == 0)
            {
                return this.firstName.ToString();
            }
            if (key.CompareTo("ListBox") != 0) return ToString();

            int yearsOld = (int)((DateTime.Now - birthday).TotalDays / 365.25);

            string firstNameListBox = FirstName;

            // Check that name is at most 8 characters long...
            if (FirstName.Length >= 9)
            {
                firstNameListBox = firstNameListBox.Remove(5);
                firstNameListBox = firstNameListBox.Insert(4, "...");
            }

            string occupationListBox = Occupation;

            // Check that occupation is at most 10 characters long...
            if (Occupation.Length >= 11)
            {
                occupationListBox = occupationListBox.Remove(8);
                occupationListBox = occupationListBox.Insert(8, "...");
            }
            
            return String.Format("{0, -8} {1, 3}  {2, -14}", firstNameListBox, yearsOld, occupationListBox);
        }
    }

}