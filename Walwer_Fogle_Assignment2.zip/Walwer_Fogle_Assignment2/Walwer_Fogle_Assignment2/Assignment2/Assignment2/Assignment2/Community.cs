﻿using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using System.Collections;
using System.Linq;

//***************************************************************************
//
//  Dylan Fogle (z1867886) and Cullen Walwer (z1839148)
//  CSCI 473/504 - Section 1
//
//***************************************************************************

namespace WindowsFormsApp1
{
    public class Community : IComparable, IEnumerable
    {
        // Private attributes.
        private SortedSet<Property> props;
        private SortedSet<Person> residents;
        private readonly uint id;
        private readonly string name;
        private uint mayorId;

        // Public properties for attributes.
        public SortedSet<Property> Props
        {
            get { return props; }
            set { props = value; }
        }

        public SortedSet<Person> Residents
        {
            get { return residents; }
            set { residents = value; }
        }

        public uint Id
        {
            get { return id; }
        }

        public string Name
        {
            get { return name; }
        }

        public uint MayorId
        {
            get { return mayorId; }
            set { }
        }

        public void addResident(Person tobeadded)
        {
            residents.Add(tobeadded);
        }

        public void addProperty(Property tobeadded)
        {
            props.Add(tobeadded);
        }

        // Get-only count of residents.
        public int Population => residents.Count;

        // Default constructor.
        public Community()
        {
            props = new SortedSet<Property>();
            residents = new SortedSet<Person>();

            // Hard code values for DeKalb community object.
            id = 99999;
            name = "DeKalb";
            mayorId = 0;
        }

        // Alternate constructor.
        public Community(SortedSet<Property> new_props, SortedSet<Person> new_residents, params string[] data)
        {
            // ID, Name, then MayorID...
            id = Convert.ToUInt32(data[0]);

            while (takenIds.ids.Contains(id)) id += 1;
            takenIds.ids.Add(id);

            name = data[1];
            mayorId = Convert.ToUInt32(data[2]);

            props = new_props;
            residents = new_residents;
        }

        // CompareTo interface.
        public int CompareTo(object alpha)
        {
            if (alpha == null) throw new ArgumentNullException();

            Community rightOp = alpha as Community;

            if (rightOp != null) return name.CompareTo(rightOp.name);
            else throw new ArgumentException("[Community]:CompareTo argument is not a Community");
        }

        // IEnumerable interface.
        IEnumerator IEnumerable.GetEnumerator()
        {
            return (IEnumerator)GetEnumerator();
        }

        public CommEnum GetEnumerator()
        {
            return new CommEnum(residents.ToArray());
        }

        // Overwritten ToString() method.
        public override string ToString()
        {
            // Find the mayor...
            Person mayor = new Person();

            foreach (Person person in residents)
            {
                if (mayorId == person.Id) mayor = person;
            }

            return "<" + id + "> " + name + ". Population (" + Population + "). Mayor: " + mayor.FullName;
        }
    }

}
