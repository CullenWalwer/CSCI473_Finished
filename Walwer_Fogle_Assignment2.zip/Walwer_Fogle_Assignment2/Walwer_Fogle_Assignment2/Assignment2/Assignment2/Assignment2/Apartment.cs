﻿using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using System.Collections;
using System.Linq;

//***************************************************************************
//
//  Dylan Fogle (z1867886) and Cullen Walwer (z1839148)
//  CSCI 473/504 - Section 1
//
//***************************************************************************

namespace WindowsFormsApp1
{
    class Apartment : Residental
    {
        //Attributes
        private string unit;

        //Properties
        public string Unit
        {
            set { unit = value; }
            get { return unit; }
        }

        //default constructor
        public Apartment() : base()
        {
            unit = "";
        }

        //data constructor
        public Apartment(params string[] data) : base(data)
        {
            unit = Convert.ToString(data[14]);
        }


        public override string ToString()
        {
            StringBuilder midString = new StringBuilder(base.ToString());
            midString.Append(String.Format(" Apt.# {0}\n", unit));
            return midString.ToString();
        }

        public override string ToString(string key)
        {
            if (key == "ListBox")
            {
                if (Forsale)
                {
                    return String.Format("{0, 19} # {1} *", StreetAddr, Unit);
                }
                else
                {
                    return String.Format("{0, 19} # {1}", StreetAddr, Unit);
                }
            }
            else if (key == "address")
            {
                return (StreetAddr + " Apt.# " + Unit + " " + City + ", " + State + ", " + Zip);
            }
            else
            {
                StringBuilder midString = new StringBuilder(base.ToString(key));
                midString.Append(String.Format(" Apt.# {0}\n", unit));
                return midString.ToString();
            }
        }

        //CompareTo handles when apartment comparisons in same building
        public override int CompareTo(object alpha)
        {

            if (base.CompareTo(alpha) == 0)
            {
                if (alpha == null) throw new ArgumentNullException();

                Apartment rightOp = alpha as Apartment;
                return unit.CompareTo(rightOp.Unit);
            }
            else { return base.CompareTo(alpha); }
        }

    }
}
