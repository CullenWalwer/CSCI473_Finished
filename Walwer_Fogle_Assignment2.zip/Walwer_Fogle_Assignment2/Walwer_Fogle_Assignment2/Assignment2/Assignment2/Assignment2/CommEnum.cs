﻿using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using System.Collections;
using System.Linq;

//***************************************************************************
//
//  Dylan Fogle (z1867886) and Cullen Walwer (z1839148)
//  CSCI 473/504 - Section 1
//
//***************************************************************************

namespace WindowsFormsApp1
{
    public class CommEnum : IEnumerator
    {
        public Person[] _residents;

        // Enumerators are positioned before the first element
        // until the first MoveNext() call.
        int position = -1;

        public CommEnum(Person[] list)
        {
            _residents = list;
        }

        public bool MoveNext()
        {
            position++;
            return (position < _residents.Length);
        }

        public void Reset()
        {
            position = -1;
        }

        object IEnumerator.Current
        {
            get
            {
                return Current;
            }
        }

        public Person Current
        {
            get
            {
                try
                {
                    return _residents[position];
                }
                catch (IndexOutOfRangeException)
                {
                    throw new InvalidOperationException();
                }
            }
        }
    }

}