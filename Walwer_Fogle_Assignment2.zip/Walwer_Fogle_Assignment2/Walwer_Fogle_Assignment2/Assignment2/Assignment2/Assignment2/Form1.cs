﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.IO;
using System.Linq;
using System.Windows.Forms;

//***************************************************************************
//
//  Dylan Fogle (z1867886) and Cullen Walwer (z1839148)
//  CSCI 473/504 - Section 1
//
//***************************************************************************

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        // Define communites, will initialize later...
        Community dekalb = new Community();
        Community sycamore = new Community();

        public Form1()
        {
            InitializeComponent();

            // Create and populate DeKalb community...
            if (Directory.Exists("../../DeKalb"))
            {
                // Define variables...
                SortedSet<Person> persons = new SortedSet<Person>();
                SortedSet<Property> props = new SortedSet<Property>();

                // Read in input data...
                string inputData;
                Nullable<UInt32> mayorId = null;

                // Read in people data...            
                if (File.Exists("../../DeKalb/p.txt"))
                {
                    using (StreamReader inFile = new StreamReader("../../DeKalb/p.txt"))
                    {
                        inputData = inFile.ReadLine();
                        while (inputData != null)
                        {
                            string[] personParams = inputData.Split();

                            // Get first person as mayor.
                            if (mayorId == null) mayorId = Convert.ToUInt32(personParams[0]);

                            Person newPerson = new Person(personParams);

                            persons.Add(newPerson);

                            inputData = inFile.ReadLine();
                        }
                    }
                }

                // Read in house data...            
                if (File.Exists("../../DeKalb/r.txt"))
                {
                    using (StreamReader inFile = new StreamReader("../../DeKalb/r.txt"))
                    {
                        inputData = inFile.ReadLine();
                        while (inputData != null)
                        {
                            string[] houseParams = new string[inputData.Split().Length];
                            houseParams = inputData.Split();

                            House newhouse = new House(houseParams);

                            props.Add(newhouse);

                            inputData = inFile.ReadLine();
                        }
                    }
                }

                // Read in apartment data...
                if (File.Exists("../../DeKalb/a.txt"))
                {
                    using (StreamReader inFile = new StreamReader("../../DeKalb/a.txt"))
                    {
                        inputData = inFile.ReadLine();
                        while (inputData != null)
                        {
                            string[] apartParams = new string[inputData.Split().Length];
                            apartParams = inputData.Split();

                            Apartment newApartment = new Apartment(apartParams);

                            props.Add(newApartment);

                            inputData = inFile.ReadLine();
                        }
                    }
                }

                // After reading in all the input data...
                dekalb = new Community(props, persons, Convert.ToString(99999), "DeKalb", Convert.ToString(mayorId));
            }

            // Create and populate Sycamore community...
            if (Directory.Exists("../../Sycamore"))
            {
                // Define variables...
                SortedSet<Person> persons = new SortedSet<Person>();
                SortedSet<Property> props = new SortedSet<Property>();

                // Read in input data...
                string inputData;
                Nullable<UInt32> mayorId = null;

                // Read in people data...            
                if (File.Exists("../../Sycamore/p.txt"))
                {
                    using (StreamReader inFile = new StreamReader("../../Sycamore/p.txt"))
                    {
                        inputData = inFile.ReadLine();
                        while (inputData != null)
                        {
                            string[] personParams = inputData.Split();

                            // Get first person as mayor.
                            if (mayorId == null) mayorId = Convert.ToUInt32(personParams[0]);

                            Person newPerson = new Person(personParams);

                            persons.Add(newPerson);

                            inputData = inFile.ReadLine();
                        }
                    }
                }

                // Read in house data...            
                if (File.Exists("../../Sycamore/r.txt"))
                {
                    using (StreamReader inFile = new StreamReader("../../Sycamore/r.txt"))
                    {
                        inputData = inFile.ReadLine();
                        while (inputData != null)
                        {
                            string[] houseParams = new string[inputData.Split().Length];
                            houseParams = inputData.Split();

                            House newhouse = new House(houseParams);

                            props.Add(newhouse);

                            inputData = inFile.ReadLine();
                        }
                    }
                }

                // Read in apartment data...
                if (File.Exists("../../Sycamore/a.txt"))
                {
                    using (StreamReader inFile = new StreamReader("../../Sycamore/a.txt"))
                    {
                        inputData = inFile.ReadLine();
                        while (inputData != null)
                        {
                            string[] apartParams = new string[inputData.Split().Length];
                            apartParams = inputData.Split();

                            Apartment newApartment = new Apartment(apartParams);

                            props.Add(newApartment);

                            inputData = inFile.ReadLine();
                        }
                    }
                }

                // After reading in all the input data...
                sycamore = new Community(props, persons, Convert.ToString(9999), "Sycamore", Convert.ToString(mayorId));
            }
        }


        private void toggle_for_sale_Click(object sender, EventArgs e)
        {
            //Error handling
            if (residence_listbox.SelectedItem == null)
            {
                guicon.Text = "ERROR: Please select a residence.";
                return;
            }

            
            if (dekalb_radio.Checked)
            {
                string selectedProp = residence_listbox.SelectedItem.ToString();
                
                //Error handling
                if ((selectedProp == "-------------\n") || (selectedProp == "Apartments:\n") || (selectedProp == "Houses:") || (selectedProp == ""))
                {
                    guicon.Text = "ERROR: Please select a residence.";
                    return;
                }

                string unit = "";

                //cut white space
                bool addressIsReady = false;
                while (!addressIsReady)
                {
                    if (selectedProp[0] == ' ')
                    {
                        selectedProp = selectedProp.Remove(0, 1);
                    }
                    else
                    {
                        addressIsReady = true;
                    }
                }

                // Remove for sale symbol...
                if (Regex.IsMatch(selectedProp, "[*]"))
                {
                    selectedProp = selectedProp.Remove(selectedProp.Length - 2);
                }

                // Check if apartment...
                if (Regex.IsMatch(selectedProp, "[#]"))
                {
                    unit = selectedProp.Substring(selectedProp.Length - 3);
                    selectedProp = selectedProp.Remove(selectedProp.Length - 6);
                }

                foreach (Property p in dekalb.Props)
                {
                    if (p.StreetAddr == selectedProp.ToString())
                    {
                        //compare unit if apartment
                        if (p is Apartment)
                        {
                            if (((Apartment)p).Unit == unit)
                            {
                                //swith for sale
                                p.Forsale = !p.Forsale;
                                dekalb_radio_CheckedChanged(sender, e);
                                if (p.Forsale) { guicon.Text = p.StreetAddr + " #" + unit + " now for sale"; }
                                else { guicon.Text = p.StreetAddr + " #" + unit + " not for sale"; }
                            }
                        }
                        else
                        {
                            //swith for sale
                            p.Forsale = !p.Forsale;
                            dekalb_radio_CheckedChanged(sender, e);
                            if (p.Forsale) { guicon.Text = p.StreetAddr + " now for sale"; }
                            else { guicon.Text = p.StreetAddr + " not for sale"; }
                        }
                    }
                }
            }

            if (sycamore_radio.Checked) { 
                string selectedProp = residence_listbox.SelectedItem.ToString();

                //error handling
                if ((selectedProp == "-------------\n") || (selectedProp == "Apartments:\n") || (selectedProp == "Houses:") || (selectedProp == ""))
                {
                      guicon.Text = "ERROR: Please select a residence.";
                      return;
                }

                string unit = "";
                
                //cut white space
                bool addressIsReady = false;
                while (!addressIsReady)
                {
                    if (selectedProp[0] == ' ')
                    {
                        selectedProp = selectedProp.Remove(0, 1);
                    }
                    else
                    {
                        addressIsReady = true;
                    }
                }

                // Remove for sale symbol...
                if (Regex.IsMatch(selectedProp, "[*]"))
                {
                    selectedProp = selectedProp.Remove(selectedProp.Length - 2);
                }

                // Check if apartment...
                if (Regex.IsMatch(selectedProp, "[#]"))
                {
                    unit = selectedProp.Substring(selectedProp.Length - 3);
                    selectedProp = selectedProp.Remove(selectedProp.Length - 6);
                }

                foreach (Property p in sycamore.Props)
                {
                    if (p.StreetAddr == selectedProp.ToString())
                    {
                        //handle if apartment
                        if (p is Apartment)
                        {
                            if (((Apartment)p).Unit == unit)
                            {
                                p.Forsale = !p.Forsale;
                                sycamore_radio_CheckedChanged(sender, e);
                                if (p.Forsale) { guicon.Text = p.StreetAddr + " #" + unit + " now for sale"; }
                                else { guicon.Text = p.StreetAddr + " #" + unit + " not for sale"; }
                            }
                        }
                        //hanle if not an apartment
                        else
                        {
                            p.Forsale = !p.Forsale;
                            sycamore_radio_CheckedChanged(sender, e);
                            if (p.Forsale) { guicon.Text = p.StreetAddr + " now for sale"; }
                            else { guicon.Text = p.StreetAddr + " not for sale"; }
                        }
                    }
                }
            }
        }

        private void buy_property_Click(object sender, EventArgs e)
        {
            //error handling 
            if (person_listbox.SelectedItem == null || residence_listbox.SelectedItem == null)
            {
                guicon.Text = "ERROR: Please Select both a Person and a Residence.\n";
                return;
            }

            if (dekalb_radio.Checked)
            {
                Person selectedPerson = dekalb.Residents.ElementAt(person_listbox.SelectedIndex);
                string selectedProp = residence_listbox.SelectedItem.ToString();
                
                //error handling
                if ((selectedProp == "-------------\n") || (selectedProp == "Apartments:\n") || (selectedProp == "Houses:") || (selectedProp == ""))
                {
                    guicon.Text = "ERROR: Please Select a Residence.";
                    return;
                }

                string unit = "";

                //cut white space
                bool addressIsReady = false;
                while (!addressIsReady)
                {
                    if (selectedProp[0] == ' ')
                    {
                        selectedProp = selectedProp.Remove(0, 1);
                    }
                    else
                    {
                        addressIsReady = true;
                    }
                }

                // Remove for sale symbol...
                if (Regex.IsMatch(selectedProp, "[*]"))
                {
                    selectedProp = selectedProp.Remove(selectedProp.Length - 2);
                }

                // Check if apartment...
                if (Regex.IsMatch(selectedProp, "[#]"))
                {
                    unit = selectedProp.Substring(selectedProp.Length - 3);
                    selectedProp = selectedProp.Remove(selectedProp.Length - 6);
                }

                foreach (Property p in dekalb.Props)
                {
                    if (p.StreetAddr == selectedProp.ToString())
                    {                       
                        if (p is Apartment)
                        {
                            //handle if apartment
                            if (((Apartment)p).Unit == unit)
                            {
                                if (p.OwnerID == selectedPerson.Id)
                                {
                                    guicon.Text = "ERROR: " + selectedPerson.FirstName + " already owns the property found at " + p.StreetAddr + ".";
                                    return;
                                }
                                else if (!p.Forsale)
                                {
                                    guicon.Text = "ERROR: Could not purchase the property at " + p.StreetAddr + ", as it is not listed for sale.";
                                    return;
                                }
                                else
                                {
                                    p.Forsale = !p.Forsale;
                                    p.OwnerID = selectedPerson.Id;
                                    dekalb_radio_CheckedChanged(sender, e);
                                    guicon.Text = "Success! " + selectedPerson.FirstName + "has purchased the property at " + p.StreetAddr + ".";

                                }
                            }
                        }
                        else
                        {
                            if (p.OwnerID == selectedPerson.Id)
                            {
                                guicon.Text = "ERROR: " + selectedPerson.FirstName + " already owns the propety found at " + p.StreetAddr + ".";
                                return;
                            }
                            else if (!p.Forsale)
                            {
                                guicon.Text = "ERROR: Could not purchase the property at " + p.StreetAddr + ", as it is not listed for sale.";
                                return;
                            }
                            else
                            {
                                p.Forsale = !p.Forsale;
                                p.OwnerID = selectedPerson.Id;
                                dekalb_radio_CheckedChanged(sender, e);
                                guicon.Text = "Success! " + selectedPerson.FirstName + "has purchased the property at " + p.StreetAddr + ".";

                            }
                        }
                    }
                }
            }

            if (sycamore_radio.Checked)
            {
                Person selectedPerson = sycamore.Residents.ElementAt(person_listbox.SelectedIndex);
                string selectedProp = residence_listbox.SelectedItem.ToString();

                //error handling 
                if ((selectedProp == "-------------\n") || (selectedProp == "Apartments:\n") || (selectedProp == "Houses:") || (selectedProp == ""))
                {
                    guicon.Text = "ERROR: Please Select a Residence.";
                    return;
                }

                string unit = "";

                //cut white space
                bool addressIsReady = false;
                while (!addressIsReady)
                {
                    if (selectedProp[0] == ' ')
                    {
                        selectedProp = selectedProp.Remove(0, 1);
                    }
                    else
                    {
                        addressIsReady = true;
                    }
                }

                // Remove for sale symbol...
                if (Regex.IsMatch(selectedProp, "[*]"))
                {
                    selectedProp = selectedProp.Remove(selectedProp.Length - 2);
                }

                // Check if apartment...
                if (Regex.IsMatch(selectedProp, "[#]"))
                {
                    unit = selectedProp.Substring(selectedProp.Length - 3);
                    selectedProp = selectedProp.Remove(selectedProp.Length - 6);
                }

                foreach (Property p in sycamore.Props)
                {
                    if (p.StreetAddr == selectedProp.ToString())
                    {
                        //handle if apartment
                        if (p is Apartment)
                        {
                            if (((Apartment)p).Unit == unit)
                            {
                                if (p.OwnerID == selectedPerson.Id)
                                {
                                    guicon.Text = "ERROR: " + selectedPerson.FirstName + " already owns the propety found at " + p.StreetAddr + ".";
                                    return;
                                }
                                else if (!p.Forsale)
                                {
                                    guicon.Text = "ERROR: Could not purchase the property at " + p.StreetAddr + ", as it is not listed for sale.";
                                    return;
                                }
                                else
                                {
                                    p.Forsale = !p.Forsale;
                                    p.OwnerID = selectedPerson.Id;
                                    sycamore_radio_CheckedChanged(sender, e);
                                    guicon.Text = "Success! " + selectedPerson.FirstName + "has purchased the property at " + p.StreetAddr + ".";

                                }
                            }
                        }
                        else
                        {
                            if (p.OwnerID == selectedPerson.Id)
                            {
                                guicon.Text = "ERROR: " + selectedPerson.FirstName + " already owns the property found at " + p.StreetAddr + ".";
                                return;
                            }
                            else if (!p.Forsale)
                            {
                                guicon.Text = "ERROR: Could not purchase the property at " + p.StreetAddr + ", as it is not listed for sale.";
                                return;
                            }
                            else
                            {
                                p.Forsale = !p.Forsale;
                                p.OwnerID = selectedPerson.Id;
                                sycamore_radio_CheckedChanged(sender, e);
                                guicon.Text = "Success! " + selectedPerson.FirstName + "has purchased the property at " + p.StreetAddr + ".";

                            }
                        }
                    }
                }
            }
        }

        private void add_resident_Click(object sender, EventArgs e)
        {
            if (person_listbox.SelectedItem == null || residence_listbox.SelectedItem == null)
            {
                guicon.Text = "ERROR: Please Select both a Person and a Residence.\n";
                return;
            }

            if (dekalb_radio.Checked)
            {
                Person selectedPerson = dekalb.Residents.ElementAt(person_listbox.SelectedIndex);
                string selectedProp = residence_listbox.SelectedItem.ToString();

                if ((selectedProp == "-------------\n") || (selectedProp == "Apartments:\n") || (selectedProp == "Houses:") || (selectedProp == ""))
                {
                    guicon.Text = "ERROR: Please Select a Residence.";
                    return;
                }

                string unit = "";

                //cut white space
                bool addressIsReady = false;
                while (!addressIsReady)
                {
                    if (selectedProp[0] == ' ')
                    {
                        selectedProp = selectedProp.Remove(0, 1);
                    }
                    else
                    {
                        addressIsReady = true;
                    }
                }

                // Remove for sale symbol...
                if (Regex.IsMatch(selectedProp, "[*]"))
                {
                    selectedProp = selectedProp.Remove(selectedProp.Length - 2);
                }

                // Check if apartment...
                if (Regex.IsMatch(selectedProp, "[#]"))
                {
                    unit = selectedProp.Substring(selectedProp.Length - 3);
                    selectedProp = selectedProp.Remove(selectedProp.Length - 6);
                }

                foreach (Property p in dekalb.Props)
                {
                    if(p.StreetAddr == selectedProp.ToString())
                    {
                        if (p is Apartment)
                        {
                            if (((Apartment)p).Unit == unit)
                            {
                                for (int i = 0; i < selectedPerson.ResidenceIds.Length; i++)
                                {
                                    if (p.Id == selectedPerson.ResidenceIds[i])
                                    {
                                        guicon.Text = selectedPerson.FirstName + " is already a resident of " + p.StreetAddr;
                                        return;
                                    }
                                }
                                selectedPerson.addResidenceId(p.Id);
                                guicon.Text = "Welcome to " + p.StreetAddr + " #" + unit + " " + selectedPerson.FirstName;
                            }
                        }
                        else
                        {
                            for (int i = 0; i < selectedPerson.ResidenceIds.Length; i++)
                            {
                                if(p.Id == selectedPerson.ResidenceIds[i])
                                {
                                    guicon.Text = selectedPerson.FirstName + " is already a resident of " + p.StreetAddr;
                                    return;
                                }
                            }
                            selectedPerson.addResidenceId(p.Id);
                            guicon.Text = "Welcome to " + p.StreetAddr + " " + selectedPerson.FirstName;
                        }
                    }
                }
            }
            
            if (sycamore_radio.Checked)
            {
                Person selectedPerson = sycamore.Residents.ElementAt(person_listbox.SelectedIndex);
                string selectedProp = residence_listbox.SelectedItem.ToString();

                if ((selectedProp == "-------------\n") || (selectedProp == "Apartments:\n") || (selectedProp == "Houses:") || (selectedProp == ""))
                {
                    guicon.Text = "ERROR: Please Select a Residence.";
                    return;
                }

                string unit = "";

                //cut white space
                bool addressIsReady = false;
                while (!addressIsReady)
                {
                    if (selectedProp[0] == ' ')
                    {
                        selectedProp = selectedProp.Remove(0, 1);
                    }
                    else
                    {
                        addressIsReady = true;
                    }
                }

                // Remove for sale symbol...
                if (Regex.IsMatch(selectedProp, "[*]"))
                {
                    selectedProp = selectedProp.Remove(selectedProp.Length - 2);
                }

                // Check if apartment...
                if (Regex.IsMatch(selectedProp, "[#]"))
                {
                    unit = selectedProp.Substring(selectedProp.Length - 3);
                    selectedProp = selectedProp.Remove(selectedProp.Length - 6);
                }

                foreach (Property p in sycamore.Props)
                {
                    if (p.StreetAddr == selectedProp.ToString())
                    {
                        if (p is Apartment)
                        {
                            if (((Apartment)p).Unit == unit)
                            {
                                for (int i = 0; i < selectedPerson.ResidenceIds.Length; i++)
                                {
                                    if (p.Id == selectedPerson.ResidenceIds[i])
                                    {
                                        guicon.Text = selectedPerson.FirstName + " is already a resident of " + p.StreetAddr;
                                        return;
                                    }
                                }
                                selectedPerson.addResidenceId(p.Id);
                                guicon.Text = "Welcome to " + p.StreetAddr + " #" + unit + " " + selectedPerson.FirstName;
                            }
                        }
                        else
                        {
                            for (int i = 0; i < selectedPerson.ResidenceIds.Length; i++)
                            {
                                if (p.Id == selectedPerson.ResidenceIds[i])
                                {
                                    guicon.Text = selectedPerson.FirstName + " is already a resident of " + p.StreetAddr;
                                    return;
                                }
                            }
                            selectedPerson.addResidenceId(p.Id);
                            guicon.Text = "Welcome to " + p.StreetAddr + " " + selectedPerson.FirstName;
                        }
                    }
                }
            }
        }

        private void remove_resident_Click(object sender, EventArgs e)
        {
            if (person_listbox.SelectedItem == null || residence_listbox.SelectedItem == null)
            {
                guicon.Text = "ERROR: Please Select both a Person and a Residence.\n";
                return;
            }

            if (dekalb_radio.Checked)
            {
                Person selectedPerson = dekalb.Residents.ElementAt(person_listbox.SelectedIndex);
                string selectedProp = residence_listbox.SelectedItem.ToString();

                if ((selectedProp == "-------------\n") || (selectedProp == "Apartments:\n") || (selectedProp == "Houses:") || (selectedProp == ""))
                {
                    guicon.Text = "ERROR: Please Select a Residence.";
                    return;
                }

                string unit = "";

                //cut white space
                bool addressIsReady = false;
                while (!addressIsReady)
                {
                    if (selectedProp[0] == ' ')
                    {
                        selectedProp = selectedProp.Remove(0, 1);
                    }
                    else
                    {
                        addressIsReady = true;
                    }
                }

                // Remove for sale symbol...
                if (Regex.IsMatch(selectedProp, "[*]"))
                {
                    selectedProp = selectedProp.Remove(selectedProp.Length - 2);
                }

                // Check if apartment...
                if (Regex.IsMatch(selectedProp, "[#]"))
                {
                    unit = selectedProp.Substring(selectedProp.Length - 3);
                    selectedProp = selectedProp.Remove(selectedProp.Length - 6);
                }

                foreach (Property p in dekalb.Props)
                {
                    if (p.StreetAddr == selectedProp.ToString())
                    {
                        if (p is Apartment)
                        {
                            if (((Apartment)p).Unit == unit)
                            {
                                for (int i = 0; i < selectedPerson.ResidenceIds.Length; i++)
                                {
                                    if (p.Id == selectedPerson.ResidenceIds[i])
                                    {
                                        selectedPerson.removeResidenceId(p.Id);
                                        guicon.Text = "Success! " + selectedPerson.FirstName + " no longer resides at the property at ";
                                        guicon.Text += p.StreetAddr + "!";
                                        return;
                                    }
                                }
                                
                                guicon.Text = selectedPerson.FirstName + " is not a residence of " + p.StreetAddr + " #" + unit;
                            }
                        }
                        else
                        {
                            for (int i = 0; i < selectedPerson.ResidenceIds.Length; i++)
                            {
                                if (p.Id == selectedPerson.ResidenceIds[i])
                                {
                                    selectedPerson.removeResidenceId(p.Id);
                                    guicon.Text = "Success! " + selectedPerson.FirstName + " no longer resides at the property at ";
                                    guicon.Text += p.StreetAddr + "!";
                                    return;
                                }
                            }
                            
                            guicon.Text = selectedPerson.FirstName + " is not a residence of " + p.StreetAddr;
                        }
                    }
                }
            }

            if (sycamore_radio.Checked)
            {
                Person selectedPerson = sycamore.Residents.ElementAt(person_listbox.SelectedIndex);
                string selectedProp = residence_listbox.SelectedItem.ToString();

                if ((selectedProp == "-------------\n") || (selectedProp == "Apartments:\n") || (selectedProp == "Houses:") || (selectedProp == ""))
                {
                    guicon.Text = "ERROR: Please Select a Residence.";
                    return;
                }

                string unit = "";

                //cut white space
                bool addressIsReady = false;
                while (!addressIsReady)
                {
                    if (selectedProp[0] == ' ')
                    {
                        selectedProp = selectedProp.Remove(0, 1);
                    }
                    else
                    {
                        addressIsReady = true;
                    }
                }

                // Remove for sale symbol...
                if (Regex.IsMatch(selectedProp, "[*]"))
                {
                    selectedProp = selectedProp.Remove(selectedProp.Length - 2);
                }

                // Check if apartment...
                if (Regex.IsMatch(selectedProp, "[#]"))
                {
                    unit = selectedProp.Substring(selectedProp.Length - 3);
                    selectedProp = selectedProp.Remove(selectedProp.Length - 6);
                }

                foreach (Property p in sycamore.Props)
                {
                    if (p.StreetAddr == selectedProp.ToString())
                    {
                        if (p is Apartment)
                        {
                            if (((Apartment)p).Unit == unit)
                            {
                                for (int i = 0; i < selectedPerson.ResidenceIds.Length; i++)
                                {
                                    if (p.Id == selectedPerson.ResidenceIds[i])
                                    {
                                        selectedPerson.removeResidenceId(p.Id);
                                        guicon.Text = "Success! " + selectedPerson.FirstName + " no longer resides at the property at ";
                                        guicon.Text += p.StreetAddr + "!";
                                        return;
                                    }
                                }

                                guicon.Text = selectedPerson.FirstName + " is not a residence of " + p.StreetAddr + " #" + unit;
                            }
                        }
                        else
                        {
                            for (int i = 0; i < selectedPerson.ResidenceIds.Length; i++)
                            {
                                if (p.Id == selectedPerson.ResidenceIds[i])
                                {
                                    selectedPerson.removeResidenceId(p.Id);
                                    guicon.Text = "Success! " + selectedPerson.FirstName + " no longer resides at the property at ";
                                    guicon.Text += p.StreetAddr + "!";
                                    return;
                                }
                            }

                            guicon.Text = selectedPerson.FirstName + " is not a residence of " + p.StreetAddr;
                        }
                    }
                }
            }
        }

        private void dekalb_radio_CheckedChanged(object sender, EventArgs e)
        {
            // Display information about the DeKalb community...
            if (dekalb_radio.Checked)
            {
                guicon.Text = "The residents and properties of DeKalb are now listed.";

                person_listbox.Items.Clear();
                residence_listbox.Items.Clear();

                residence_listbox.Items.Add("Houses:\n");
                residence_listbox.Items.Add("-------------\n");

                foreach (Person p in dekalb)
                {
                    person_listbox.Items.Add(p.ToString("ListBox"));
                }

                foreach (Property p in dekalb.Props)
                {
                    if (p is House)
                    {
                        residence_listbox.Items.Add(p.ToString("ListBox"));
                        residence.Items.Add(p.StreetAddr);
                    }
                }
 
                residence_listbox.Items.Add("\n");
                residence_listbox.Items.Add("Apartments:\n");
                residence_listbox.Items.Add("-------------\n");
                
                foreach (Property p in dekalb.Props)
                {
                    if (p is Apartment)
                    {
                        residence_listbox.Items.Add(p.ToString("ListBox"));
                        residence.Items.Add(p.StreetAddr + " # " + (p as Apartment).Unit);
                    }
                }
            }
        }

        private void sycamore_radio_CheckedChanged(object sender, EventArgs e)
        {
            // Display information about the Sycamore community...
            if (sycamore_radio.Checked)
            {
                guicon.Text = "The residents and properties of Sycamore are now listed.";

                person_listbox.Items.Clear();
                residence_listbox.Items.Clear();

                foreach (Person p in sycamore)
                {
                    person_listbox.Items.Add(p.ToString("ListBox"));
                }

                residence_listbox.Items.Add("Houses:\n");
                residence_listbox.Items.Add("-------------\n");

                foreach (Property p in sycamore.Props)
                {
                    if (p is House)
                    {
                        residence_listbox.Items.Add(p.ToString("ListBox"));
                        residence.Items.Add(p.StreetAddr);
                    }
                }

                residence_listbox.Items.Add("\n");
                residence_listbox.Items.Add("Apartments:\n");
                residence_listbox.Items.Add("-------------\n");

                foreach (Property p in sycamore.Props)
                {
                    if (p is Apartment)
                    {
                        residence_listbox.Items.Add(p.ToString("ListBox"));
                        residence.Items.Add(p.StreetAddr + " # " + (p as Apartment).Unit);
                    }
                }
            }
        }

        // I can't seem to find this textbox...
        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        // Show output of currently selected person.
        private void person_listbox_SelectedIndexChanged(object sender, EventArgs e)
        {   if(person_listbox.SelectedItem == null)
            {
                return;
            }
            // Person is in DeKalb community.
            if (dekalb_radio.Checked)
            {
                
                Person selectedPerson = dekalb.Residents.ElementAt(person_listbox.SelectedIndex);

                guicon.Text = selectedPerson.ToString() + ", who resides at:";

                foreach(uint residenceId in selectedPerson.ResidenceIds)
                {
                    foreach (Property p in dekalb.Props)
                    {
                        if (residenceId == p.Id)
                        {
                            guicon.Text += "\n       " + p.StreetAddr;
                        }
                    }
                }
            }
            // Person is in Sycamore community.
            else
            {
                Person selectedPerson = sycamore.Residents.ElementAt(person_listbox.SelectedIndex);

                guicon.Text = selectedPerson.ToString() + ", who resides at:";

                foreach (uint residenceId in selectedPerson.ResidenceIds)
                {
                    foreach (Property p in sycamore.Props)
                    {
                        if (residenceId == p.Id)
                        {
                            guicon.Text += "\n       " + p.StreetAddr;
                        }
                    }
                }
            }

            guicon.Text += "\n\n### END OUTPUT ###";
        }

        // Show output of currently selected residence.
        private void residence_listbox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(residence_listbox.SelectedItem == null)
            {
                return;
            }
            // Instead of looking at the index, like in the case of the Person listbox,
            // here we can use the address itself to compare against the addresses in the community.
            // To ensure it is an address, we can check if it contains numbers.

            // Residence is in DeKalb community.
            if (dekalb_radio.Checked)
            {
                string selectedAddress = residence_listbox.SelectedItem.ToString();
                string unit = "";

                if (selectedAddress == "") return;

                // Remove leading whitespace...
                bool addressIsReady = false;
                while (!addressIsReady)
                {
                    if (selectedAddress[0] == ' ')
                    {
                        selectedAddress = selectedAddress.Remove(0, 1);
                    }
                    else
                    {
                        addressIsReady = true;
                    }
                }

                // Remove for sale symbol...
                if (Regex.IsMatch(selectedAddress, "[*]"))
                {
                    selectedAddress = selectedAddress.Remove(selectedAddress.Length - 2);
                }

                // Check if apartment...
                if (Regex.IsMatch(selectedAddress, "[#]"))
                {
                    unit = selectedAddress.Substring(selectedAddress.Length - 3);
                    selectedAddress = selectedAddress.Remove(selectedAddress.Length - 6);
                }

                if(Regex.IsMatch(selectedAddress, "[0-9]"))
                {
                    foreach (Property p in dekalb.Props)
                    {
                        if (unit != "")
                        {
                            if (p.StreetAddr == selectedAddress && (p as Apartment).Unit == unit)
                            {
                                string owner = "";

                                foreach (Person person in dekalb)
                                {
                                    if (person.Id == p.OwnerID)
                                    {
                                        owner = person.FullName;
                                    }
                                }

                                guicon.Text = "Residents living at " + selectedAddress + " # " + unit + ", DeKalb, owned by ";
                                guicon.Text += owner + ":";
                                guicon.Text += "\n----------------------------------------------------------------\n";

                                foreach (Person person in dekalb)
                                {
                                    if (person.ResidenceIds.Contains(p.Id))
                                    {
                                        int yearsOld = (int)((DateTime.Now - person.Birthday).TotalDays / 365.25);

                                        guicon.Text += String.Format("{0, -20} {1, 3} {2, 24}\n", person.FullName, yearsOld, person.Occupation);
                                    }
                                }
                            }
                        }
                        else if (p.StreetAddr == selectedAddress)
                        {
                            string owner = "";

                            foreach (Person person in dekalb)
                            {
                                if (person.Id == p.OwnerID)
                                {
                                    owner = person.FullName;
                                }
                            }

                            guicon.Text = "Residents living at " + selectedAddress + ", DeKalb, owned by ";
                            guicon.Text += owner + ":";
                            guicon.Text += "\n----------------------------------------------------------------\n";

                            foreach (Person person in dekalb)
                            {
                                if (person.ResidenceIds.Contains(p.Id))
                                {
                                    int yearsOld = (int)((DateTime.Now - person.Birthday).TotalDays / 365.25);

                                    guicon.Text += String.Format("{0, -20} {1, 3} {2, 24}\n", person.FullName, yearsOld, person.Occupation);
                                }
                            }
                        }
                    }

                    guicon.Text += "\n### END OUTPUT ###";
                }
            }
            // Residence is in Sycamore community.
            else
            {
                string selectedAddress = residence_listbox.SelectedItem.ToString();
                string unit = "";

                if (selectedAddress == "") return;

                // Remove leading whitespace...
                bool addressIsReady = false;
                while (!addressIsReady)
                {
                    if (selectedAddress[0] == ' ')
                    {
                        selectedAddress = selectedAddress.Remove(0, 1);
                    }
                    else
                    {
                        addressIsReady = true;
                    }
                }

                // Remove for sale symbol...
                if (Regex.IsMatch(selectedAddress, "[*]"))
                {
                    selectedAddress = selectedAddress.Remove(selectedAddress.Length - 2);
                }

                // Check if apartment...
                if (Regex.IsMatch(selectedAddress, "[#]"))
                {
                    unit = selectedAddress.Substring(selectedAddress.Length - 3);
                    selectedAddress = selectedAddress.Remove(selectedAddress.Length - 6);
                }

                if (Regex.IsMatch(selectedAddress, "[0-9]"))
                {
                    foreach (Property p in sycamore.Props)
                    {
                        if (unit != "")
                        {
                            if (p.StreetAddr == selectedAddress && (p as Apartment).Unit == unit)
                            {
                                string owner = "";

                                foreach (Person person in sycamore)
                                {
                                    if (person.Id == p.OwnerID)
                                    {
                                        owner = person.FullName;
                                    }
                                }

                                guicon.Text = "Residents living at " + selectedAddress + " # " + unit + ", Sycamore, owned by ";
                                guicon.Text += owner + ":";
                                guicon.Text += "\n----------------------------------------------------------------\n";

                                foreach (Person person in sycamore)
                                {
                                    if (person.ResidenceIds.Contains(p.Id))
                                    {
                                        int yearsOld = (int)((DateTime.Now - person.Birthday).TotalDays / 365.25);

                                        guicon.Text += String.Format("{0, -20} {1, 3} {2, 24}\n", person.FullName, yearsOld, person.Occupation);
                                    }
                                }
                            }
                        }
                        else if (p.StreetAddr == selectedAddress)
                        {
                            string owner = "";

                            foreach (Person person in sycamore)
                            {
                                if (person.Id == p.OwnerID)
                                {
                                    owner = person.FullName;
                                }
                            }

                            guicon.Text = "Residents living at " + selectedAddress + ", Sycamore, owned by ";
                            guicon.Text += owner + ":";
                            guicon.Text += "\n----------------------------------------------------------------\n";

                            foreach (Person person in sycamore)
                            {
                                if (person.ResidenceIds.Contains(p.Id))
                                {
                                    int yearsOld = (int)((DateTime.Now - person.Birthday).TotalDays / 365.25);

                                    guicon.Text += String.Format("{0, -20} {1, 3} {2, 24}\n", person.FullName, yearsOld, person.Occupation);
                                }
                            }
                        }
                    }

                    guicon.Text += "\n### END OUTPUT ###";
                }
            }
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        //Add Resident button
        private void addResident_Click_1(object sender, EventArgs e)
        {
            // Check for missing values...
            if (newName.Text.CompareTo("") == 0)
            {
                guicon.Text = "ERROR: Please enter a name for this new resident.";
                return;
            }
            else if (newOccupation.Text.CompareTo("") == 0)
            {
                guicon.Text = "ERROR: Please enter an occupation for this new resident.";
                return;
            }
            else if (DateTime.Now < birthday.Value)
            {
                guicon.Text = "ERROR: Birthdays cannot be defined from future dates.";
                return;
            }
            else if (residence.Text.CompareTo("") == 0)
            {
                guicon.Text = "ERROR: Please select a residence for this new resident to reside at.";
                return;
            }
            else if (!dekalb_radio.Checked && !sycamore_radio.Checked)
            {
                guicon.Text = "ERROR: Please select a community for this new resident.";
                return;
            }

            // Retrieve birthday values...
            string birthD = Convert.ToString(birthday.Value.Day);
            string birthM = Convert.ToString(birthday.Value.Month);
            string birthY = Convert.ToString(birthday.Value.Year);

            // Retrieve new residence ID value from name...
            uint newResidence = 0;

            // If new residence is an apartment...
            if (Regex.IsMatch(residence.Text, "[#]"))
            {
                string unit = residence.Text.Substring(residence.Text.Length - 3);

                // Find the apartment ID...
                if (dekalb_radio.Checked)
                {
                    foreach (Property p in dekalb.Props)
                    {
                        if (p is Apartment)
                        {
                            if (unit == (p as Apartment).Unit) newResidence = p.Id;
                        }
                    }
                }
                else
                {
                    foreach (Property p in sycamore.Props)
                    {
                        if (p is Apartment)
                        {
                            if (unit == (p as Apartment).Unit) newResidence = p.Id;
                        }
                    }
                }
            }
            else
            {
                // Find the house ID...
                if (dekalb_radio.Checked)
                {
                    foreach (Property p in dekalb.Props)
                    {
                        if (p is House)
                        {
                            if (residence.Text == p.StreetAddr) newResidence = p.Id;
                        }
                    }
                }
                else
                {
                    foreach (Property p in sycamore.Props)
                    {
                        if (p is House)
                        {
                            if (residence.Text == p.StreetAddr) newResidence = p.Id;
                        }
                    }
                }
            }

            // Create new resident...
            Person newResident = new Person("0", newName.Text.Split()[1], newName.Text.Split()[0], newOccupation.Text,
                                            birthY, birthM, birthD, Convert.ToString(newResidence));

            // Add new resident to respective community...
            if (dekalb_radio.Checked)
            {
                // In the edge case where two people have the same name...
                foreach (Person p in dekalb)
                {
                    if (p.FullName.CompareTo(newResident.FullName) == 0)
                    {
                        guicon.Text = "ERROR: A resident by the name " + newResident.FullName + " already lives in DeKalb!";
                        return;
                    }
                }

                dekalb.addResident(newResident);

                guicon.Text = "Success! " + newName.Text.Split()[0] + " has been added as a resident to DeKalb!";

                // Update residence list.
                dekalb_radio_CheckedChanged(sender, e);

                newName.Text = "";
                newOccupation.Text = "";
            }
            else
            {
                // In the edge case where two people have the same name...
                foreach (Person p in dekalb)
                {
                    if (p.FullName.CompareTo(newResident.FullName) == 0)
                    {
                        guicon.Text = "ERROR: A resident by the name " + newResident.FullName + " already lives in Sycamore!";
                        return;
                    }
                }

                sycamore.addResident(newResident);

                guicon.Text = "Success! " + newName.Text.Split()[0] + " has been added as a resident to Sycamore!";

                // Update residence list.
                sycamore_radio_CheckedChanged(sender, e);

                newName.Text = "";
                newOccupation.Text = "";
            }
        }

        //Add Property button
        private void add_property_Click(object sender, EventArgs e)
        {
            // Check for missing values...
            if (newAddress.Text.CompareTo("") == 0)
            {
                guicon.Text = "ERROR: Please enter an address for this property! Ex. 123 Street Rd.";
                return;
            }

            // I don't think we need to retrieve the City, State, and Zip code from the newAddress line.
            // We can look at the community and use the values for it.

            string[] arrayAddress = newAddress.Text.Split();

            // Prepare data for a new property...
            uint ownerId = 0;
            while (takenIds.ids.Contains(ownerId)) ownerId += 1;
            takenIds.ids.Add(ownerId);

            int squareX = (int)Math.Sqrt((double)newSquareFoots.Value);
            int squareY = squareX;

            string streetAddress = arrayAddress[0];
            string streetName = arrayAddress[1];
            string streetRd = arrayAddress[2];

            string city;
            string state;
            string zip;

            if (dekalb_radio.Checked)
            {
                city = "DeKalb";
                state = "Illinois";
                zip = "60115";
            }
            else
            {
                city = "Sycamore";
                state = "Illinois";
                zip = "60178";
            }

            int bedrooms = (int)newBed.Value;
            int bathrooms = (int)newBath.Value;
            int squarefeet = squareX * squareY;

            // New property is a house...
            if (newAptnum.Text.CompareTo("") == 0)
            {
                string garage = "F";
                string isAttached = "F";
                int floors = (int)newNumFloors.Value;

                if (newGarage.Checked) garage = "T";
                if (attached.Checked) isAttached = "T";

                House newHouse = new House("0", Convert.ToString(ownerId), Convert.ToString(squareX), Convert.ToString(squareY),
                                            streetAddress, streetName, streetRd, city, state, zip, "T", Convert.ToString(bedrooms),
                                            Convert.ToString(bathrooms), Convert.ToString(squarefeet), garage, isAttached,
                                            Convert.ToString(floors));

                if (dekalb_radio.Checked)
                {
                    dekalb.addProperty(newHouse);

                    dekalb_radio_CheckedChanged(sender, e);

                    guicon.Text = "Success! A new property at " + newHouse.StreetAddr + " has been added to DeKalb!";
                }
                else
                {
                    sycamore.addProperty(newHouse);

                    sycamore_radio_CheckedChanged(sender, e);

                    guicon.Text = "Success! A new property at " + newHouse.StreetAddr + " has been added to Sycamore!";
                }
            }
            // New property is an apartment...
            else
            {
                string unit = newAptnum.Text;

                Apartment newApartment = new Apartment("0", Convert.ToString(ownerId), Convert.ToString(squareX), Convert.ToString(squareY),
                                                        streetAddress, streetName, streetRd, city, state, zip, "T", Convert.ToString(bedrooms),
                                                        Convert.ToString(bathrooms), Convert.ToString(squarefeet), unit);

                if (dekalb_radio.Checked)
                {
                    dekalb.addProperty(newApartment);

                    dekalb_radio_CheckedChanged(sender, e);

                    guicon.Text = "Success! A new property at " + newApartment.StreetAddr + " has been added to DeKalb!";
                }
                else
                {
                    sycamore.addProperty(newApartment);

                    sycamore_radio_CheckedChanged(sender, e);

                    guicon.Text = "Success! A new property at " + newApartment.StreetAddr + " has been added to Sycamore!";
                }
            }

            // Reset input form...
            newAddress.Text = "";
            newAptnum.Text = "";
            newSquareFoots.Value = 500;
            newBed.Value = 1;
            newBath.Value = 1;
            newNumFloors.Value = 1;
            newGarage.Checked = false;
            attached.Checked = false;
        }

        private void newGarage_CheckedChanged(object sender, EventArgs e)
        {
            if (newGarage.Checked)
            {
                attached.Enabled = true;
            }
            else
            {
                attached.Enabled = false;
            }
        }

        private void guicon_TextChanged(object sender, EventArgs e)
        {

        }

        private void community_groupbox_Enter(object sender, EventArgs e)
        {

        }

        private void add_property_groupbox_Enter(object sender, EventArgs e)
        {

        }

        private void add_new_resident_groupbox_Enter(object sender, EventArgs e)
        {

        }

        private void newAptnum_TextChanged(object sender, EventArgs e)
        {
            if (newAptnum.Text != "")
            {
                newGarage.Enabled = false;
                attached.Enabled = false;
            }
            else
            {
                newGarage.Enabled = true;
            }
        }
    }
}
