﻿using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using System.Collections;
using System.Linq;

//***************************************************************************
//
//  Dylan Fogle (z1867886) and Cullen Walwer (z1839148)
//  CSCI 473/504 - Section 1
//
//***************************************************************************

namespace Assignment1
{

    class Residental : Property
    {
        //Attributes
        protected uint bedrooms;
        protected uint baths;
        protected uint sqft;

        //Properties
        public uint Bedrooms
        {
            set { bedrooms = value; }
            get { return bedrooms; }
        }
        public uint Baths
        {
            set { baths = value; }
            get { return baths; }
        }
        public uint Sqft
        {
            set { sqft = value; }
            get { return sqft; }
        }

        //default constructor
        public Residental() : base()
        {
            bedrooms = 0;
            baths = 0;
            sqft = 0;
        }

        //data constructor
        public Residental(params object[] data) : base(data)
        {
            bedrooms = Convert.ToUInt32(data[11]);
            baths = Convert.ToUInt32(data[12]);
            sqft = Convert.ToUInt32(data[13]);
        }

        //ToString, No owner Info
        public override string ToString()
        {
            StringBuilder midString = new StringBuilder(base.ToString());
            midString.Append(String.Format("        {0} bedrooms \\ {1} baths \\ {2} sq.ft.", bedrooms, baths, sqft));
            return midString.ToString();
        }

        //ToString, Owner Info
        public override string ToString(string ownerInfo)
        {
            StringBuilder midString = new StringBuilder(base.ToString());
            midString.Append(String.Format("        Owned by {0}\n", ownerInfo));

            if (Forsale) midString.Append("        (FOR SALE) ");
            else midString.Append("        (NOT for sale) ");

            midString.Append(String.Format("{0} bedrooms \\ {1} baths \\ {2} sq.ft.", bedrooms, baths, sqft));
            return midString.ToString();
        }
    }
}
