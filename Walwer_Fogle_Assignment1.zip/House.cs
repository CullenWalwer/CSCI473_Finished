﻿using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using System.Collections;
using System.Linq;

//***************************************************************************
//
//  Dylan Fogle (z1867886) and Cullen Walwer (z1839148)
//  CSCI 473/504 - Section 1
//
//***************************************************************************

namespace Assignment1
{
    class House : Residental
    {
        //Attributes
        private bool garage;
        private Nullable<bool> attachedGarage;
        private uint floors;

        //properties
        public bool Garage
        {
            set
            {
                garage = value;

                //if no garage attachedGarage = null 
                if (!garage)
                {
                    attachedGarage = null;
                }
            }
            get { return garage; }
        }
        public Nullable<bool> AttachedGarage
        {
            get { return attachedGarage; }
            //may only be set if a garage has value
            set { if (attachedGarage.HasValue) { attachedGarage = value; } }
        }
        public uint Floors
        {
            set { floors = value; }
            get { return floors; }
        }

        //default constructor
        public House() : base()
        {
            garage = false;
            attachedGarage = null;
            floors = 1;
        }

        //data constructor
        public House(params object[] data) : base(data)
        {
            //if has a garage then attachedGarage has value
            if (Convert.ToString(data[14]) == "T")
            {
                garage = true;
                if (Convert.ToString(data[15]) == "T")
                {
                    attachedGarage = true;
                }
                else
                {
                    attachedGarage = false;
                }
            }
            //no garage attachedGarage is null 
            else
            {
                garage = false;
                attachedGarage = null;
            }
            floors = Convert.ToUInt32(data[16]);
        }

        //ToString default
        public override string ToString()
        {
            StringBuilder midString = new StringBuilder(base.ToString());
            if (garage)
            {
                //check for null caracter
                bool garagePosition = attachedGarage ?? false;
                if (garagePosition)
                {
                    midString.Append(String.Format("\n        ... with an attached garage : {0} floors.\n", floors));
                }
                if (!garagePosition)
                {
                    midString.Append(String.Format("\n        ... with a detached garage : {0} floors.\n", floors));
                }
            }
            else
            {
                midString.Append(String.Format("\n        ... with no garage : {0} floors.\n", floors));
            }
            return midString.ToString();
        }

        //ToString with address option 
        public override string ToString(string key)
        {
            if (key == "address")
            {
                return (StreetAddr + " " + City + ", " + State + ", " + Zip);
            }
            else
            {
                StringBuilder midString = new StringBuilder(base.ToString(key));
                if (garage)
                {
                    bool garagePosition = attachedGarage ?? false;
                    if (garagePosition)
                    {
                        midString.Append(String.Format("\n        ... with an attached garage : {0} floors.\n", floors));
                    }
                    if (!garagePosition)
                    {
                        midString.Append(String.Format("\n        ... with a detached garage : {0} floors.\n", floors));
                    }
                }
                else
                {
                    midString.Append(String.Format("\n        ... with no garage : {0} floors.\n", floors));
                }
                return midString.ToString();
            }
        }

    }
}
