﻿using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using System.Collections;
using System.Linq;

//***************************************************************************
//
//  Dylan Fogle (z1867886) and Cullen Walwer (z1839148)
//  CSCI 473/504 - Section 1
//
//***************************************************************************

namespace Assignment1
{
    public class Property : IComparable
    {
        //Attributes
        protected readonly uint id;
        protected uint ownerID;
        protected readonly uint x;
        protected readonly uint y;
        protected string streetAddr;
        protected string city;
        protected string state;
        protected string zip;
        protected bool forSale;

        //properties
        public uint Id
        {
            //no set, readonly 
            get { return id; }
        }
        public uint OwnerID
        {
            set { ownerID = value; }
            get { return ownerID; }
        }
        public uint X
        {
            //no set, readonly
            get { return x; }
        }
        public uint Y
        {
            //no set, readonly
            get { return y; }
        }
        public string StreetAddr
        {
            set { streetAddr = value; }
            get { return streetAddr; }
        }
        public string City
        {
            set { city = value; }
            get { return city; }
        }
        public string State
        {
            get { return state; }
            set { state = value; }
        }
        public string Zip
        {
            get { return zip; }
            set { zip = value; }
        }
        public bool Forsale
        {
            set { forSale = value; }
            get { return forSale; }
        }

        //default constructor
        public Property()
        {
            //takenIds is used to generate an id that has not been used already
            id = (uint)takenIds.ids.Count;
            while (takenIds.ids.Contains(id)) id = id++;
            takenIds.ids.Add(id);

            //default assignments
            ownerID = 0;
            x = 0;
            y = 0;
            streetAddr = "";
            city = "";
            state = "";
            zip = "";
            forSale = false;

        }

        //data constructor
        public Property(params string[] data)
        {
            id = Convert.ToUInt32(data[0]);

            while (takenIds.ids.Contains(id)) id += 1;
            takenIds.ids.Add(id);

            ownerID = Convert.ToUInt32(data[1]);
            x = Convert.ToUInt32(data[2]);
            y = Convert.ToUInt32(data[3]);

            //combine street number, name, and road type
            //note: assumes perfect inpute of three parts
            int combineUpTO = 7;
            StringBuilder sb = new StringBuilder("");
            for (int i = 4; i < combineUpTO; i++)
            {
                sb.Append(data[i].ToString());
                if (i + 1 != combineUpTO)
                {
                    sb.Append(" ");
                }
            }
            streetAddr = sb.ToString();

            city = Convert.ToString(data[combineUpTO]);         //always 7 in a1
            state = Convert.ToString(data[combineUpTO + 1]);    //always 8 in a1
            zip = Convert.ToString(data[combineUpTO + 2]);      //always 9 in a1
            if (Convert.ToString(data[combineUpTO + 3]) == "T") //always 10 in a1
            {
                forSale = true;
            }
            else
            {
                forSale = false;
            }
        }

        //compareTo for all propertys
        //overloaded in apartments   
        public virtual int CompareTo(object alpha)
        {
            // Check for null value.
            if (alpha == null) throw new ArgumentNullException();

            Property rightOp = alpha as Property;

            if (rightOp != null)
            {
                //if state is the same compare city
                if (state.CompareTo(rightOp.state) == 0)
                {
                    //if city is the same compare street name
                    if (city.CompareTo(rightOp.city) == 0)
                    {
                        //split number and name of street for both items being compared
                        string[] sep = { " " };
                        Int32 count = 2;
                        string[] splitStreetAddr = streetAddr.Split(sep, count, StringSplitOptions.RemoveEmptyEntries);
                        string[] splitRightOp = rightOp.streetAddr.Split(sep, count, StringSplitOptions.RemoveEmptyEntries);

                        //if name is the same compare number
                        if (splitStreetAddr[1].CompareTo(splitRightOp[1]) == 0)
                        {
                            //compare number
                            return splitStreetAddr[0].CompareTo(splitRightOp[0]);
                        }
                        else { return splitStreetAddr[1].CompareTo(splitRightOp[1]); }
                    }
                    else { return city.CompareTo(rightOp.city); }
                }
                else { return state.CompareTo(rightOp.state); }
            }
            else throw new ArgumentException("[Property]:CompareTo argument is not a Property!");
        }

        //default ToString for Property, no owner 
        public override string ToString()
        {
            return string.Format("Property Address: {0} / {1} / {2} / {3}\n", streetAddr, city, state, zip);
        }

        //virtual ToString for property, owner
        public virtual string ToString(string ownerInfo)
        {
            return string.Format("Property Address: {0}. / {1} / {2} / {3}\n        Owned by {4}\n", streetAddr, city, state, zip, ownerInfo);
        }

    }
}