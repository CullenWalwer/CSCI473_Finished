﻿using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using System.Collections;
using System.Linq;

//***************************************************************************
//
//  Dylan Fogle (z1867886) and Cullen Walwer (z1839148)
//  CSCI 473/504 - Section 1
//
//***************************************************************************

namespace Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Define communites, will initialize later...
            Community dekalb = new Community();
            Community sycamore = new Community();

            // Create and populate DeKalb community...
            if (Directory.Exists("../../DeKalb"))
            {
                // Define variables...
                SortedSet<Person> persons = new SortedSet<Person>();
                SortedSet<Property> props = new SortedSet<Property>();

                // Read in input data...
                string inputData;
                Nullable<UInt32> mayorId = null;

                // Read in people data...            
                if (File.Exists("../../DeKalb/p.txt"))
                {
                    using (StreamReader inFile = new StreamReader("../../DeKalb/p.txt"))
                    {
                        inputData = inFile.ReadLine();
                        while (inputData != null)
                        {
                            string[] personParams = inputData.Split();

                            // Get first person as mayor.
                            if (mayorId == null) mayorId = Convert.ToUInt32(personParams[0]);

                            Person newPerson = new Person(personParams);

                            persons.Add(newPerson);

                            inputData = inFile.ReadLine();
                        }
                    }
                }

                // Read in house data...            
                if (File.Exists("../../DeKalb/r.txt"))
                {
                    using (StreamReader inFile = new StreamReader("../../DeKalb/r.txt"))
                    {
                        inputData = inFile.ReadLine();
                        while (inputData != null)
                        {
                            string[] houseParams = new string[inputData.Split().Length];
                            houseParams = inputData.Split();

                            House newhouse = new House(houseParams);

                            props.Add(newhouse);

                            inputData = inFile.ReadLine();
                        }
                    }
                }

                // Read in apartment data...
                if (File.Exists("../../DeKalb/a.txt"))
                {
                    using (StreamReader inFile = new StreamReader("../../DeKalb/a.txt"))
                    {
                        inputData = inFile.ReadLine();
                        while (inputData != null)
                        {
                            string[] apartParams = new string[inputData.Split().Length];
                            apartParams = inputData.Split();

                            Apartment newApartment = new Apartment(apartParams);

                            props.Add(newApartment);

                            inputData = inFile.ReadLine();
                        }
                    }
                }

                // After reading in all the input data...
                dekalb = new Community(props, persons, Convert.ToString(99999), "DeKalb", Convert.ToString(mayorId));
            }

            // Create and populate Sycamore community...
            if (Directory.Exists("../../Sycamore"))
            {
                // Define variables...
                SortedSet<Person> persons = new SortedSet<Person>();
                SortedSet<Property> props = new SortedSet<Property>();

                // Read in input data...
                string inputData;
                Nullable<UInt32> mayorId = null;

                // Read in people data...            
                if (File.Exists("../../Sycamore/p.txt"))
                {
                    using (StreamReader inFile = new StreamReader("../../Sycamore/p.txt"))
                    {
                        inputData = inFile.ReadLine();
                        while (inputData != null)
                        {
                            string[] personParams = inputData.Split();

                            // Get first person as mayor.
                            if (mayorId == null) mayorId = Convert.ToUInt32(personParams[0]);

                            Person newPerson = new Person(personParams);

                            persons.Add(newPerson);

                            inputData = inFile.ReadLine();
                        }
                    }
                }
                
                // Read in house data...            
                if (File.Exists("../../Sycamore/r.txt"))
                {
                    using (StreamReader inFile = new StreamReader("../../Sycamore/r.txt"))
                    {
                        inputData = inFile.ReadLine();
                        while (inputData != null)
                        {
                            string[] houseParams = new string[inputData.Split().Length];
                            houseParams = inputData.Split();

                            House newhouse = new House(houseParams);

                            props.Add(newhouse);

                            inputData = inFile.ReadLine();
                        }
                    }
                }

                // Read in apartment data...
                if (File.Exists("../../Sycamore/a.txt"))
                {
                    using (StreamReader inFile = new StreamReader("../../Sycamore/a.txt"))
                    {
                        inputData = inFile.ReadLine();
                        while (inputData != null)
                        {
                            string[] apartParams = new string[inputData.Split().Length];
                            apartParams = inputData.Split();

                            Apartment newApartment = new Apartment(apartParams);

                            props.Add(newApartment);

                            inputData = inFile.ReadLine();
                        }
                    }
                }
                
                // After reading in all the input data...
                sycamore = new Community(props, persons, Convert.ToString(9999), "Sycamore", Convert.ToString(mayorId));
            }

            Console.WriteLine(dekalb);
            Console.WriteLine(sycamore);

            // Print menu.
            Console.WriteLine(" 1. Full property list");
            Console.WriteLine(" 2. List addresses of either House or Apartment-type properties");
            Console.WriteLine(" 3. List addresses of all for-sale properties");
            Console.WriteLine(" 4. List all residents of a community");
            Console.WriteLine(" 5. List all residents of a property, by street address");
            Console.WriteLine(" 6. Toggle a property, by street address, as being for-sale or not.");
            Console.WriteLine(" 7. Buy a for-sale property, by street address");
            Console.WriteLine(" 8. Add yourself as an occupant to a property.");
            Console.WriteLine(" 9. Remove yourself as an occupant from a property");
            Console.WriteLine("10. Quit\n");

            // Account for user input as array, only look at first element.
            string[] userInput = Console.ReadLine().Split();
            while (userInput[0] != null)
            {
                int menuItem = 0;
                Int32.TryParse(userInput[0], out menuItem);

                switch (menuItem)
                {
                    case 0: // Parse as string for quit.
                        if (userInput[0] == "q" || userInput[0] == "quit" || userInput[0] == "e" || userInput[0] == "exit")
                        {
                            Console.WriteLine("Quitting program...");
                            return;
                        }

                        Console.WriteLine("Invalid input. Please enter a number from 1 to 10! Please try again!");
                        break;
                    case 1: // Full property list.
                        Console.WriteLine(dekalb);
                        Console.WriteLine("--------------------------------------------------\n");

                        foreach (Property property in dekalb.Props)
                        {
                            Person owner = new Person();
                            bool ownerFound = false;

                            foreach (Person p in dekalb.Residents)
                            {
                                if (p.Id == property.OwnerID)
                                {
                                    owner = p;
                                    ownerFound = true;
                                }
                            }

                            if (ownerFound) Console.WriteLine(property.ToString(owner.ToString()));
                            else Console.WriteLine(property.ToString());
                        }

                        break;
                    case 2: // List addresses of either House or Apartment-type properties.
                        Console.WriteLine("Enter property type (House/Apartment):\n");

                        // Get user input...
                        string propType = Console.ReadLine();

                        if (propType == "Apartment")
                        {
                            Console.WriteLine("\nList of addresses of {0} properties in the DeKalb community.", propType);
                            Console.WriteLine("----------------------------------------------------------\n");

                            foreach (Property property in dekalb.Props)
                            {
                                if (property is Apartment) Console.WriteLine(property.ToString("address"));
                            }
                        }
                        else if (propType == "House")
                        {
                            Console.WriteLine("\nList of addresses of {0} properties in the DeKalb community.", propType);
                            Console.WriteLine("----------------------------------------------------------\n");

                            foreach (Property property in dekalb.Props)
                            {
                                if (property is House) Console.WriteLine(property.ToString("address"));
                            }
                        }
                        else Console.WriteLine("Invalid input, please enter either 'House' or 'Apartment'.");
                        Console.WriteLine();

                        break;
                    case 3: // List addresses of all for-sale properties.
                        Console.WriteLine("\nList of addresses for all FOR SALE properties in the DeKalb community.");
                        Console.WriteLine("---------------------------------------------------------\n");

                        foreach (Property property in dekalb.Props)
                        {
                            if (property.Forsale) Console.WriteLine(property.ToString("address"));
                        }

                        Console.WriteLine();

                        break;
                    case 4: // List all residents of a community.
                        Console.WriteLine("List of all residents living in the DeKalb community.");
                        Console.WriteLine("--------------------------------------------------\n");

                        foreach (Person p in dekalb)
                        {
                            Console.WriteLine(p);
                            Console.WriteLine();
                        }

                        break;
                    case 5: // List all residents of a property, by street address.
                        Console.WriteLine("Enter the street address to lookup:");

                        // Get user input...
                        string addressToLook = Console.ReadLine();

                        // Get id of property...
                        uint idToLook = 0;

                        foreach (Property p in dekalb.Props)
                        {
                            if (addressToLook == p.StreetAddr) idToLook = p.Id;
                        }

                        // Check if address is valid...
                        if (idToLook == 0)
                        {
                            Console.WriteLine("I'm sorry, I don't recognize this address: '{0}'.", addressToLook);
                        }
                        else
                        {
                            Console.WriteLine("List of all residents at {0}:", addressToLook);
                            Console.WriteLine("---------------------------------------------------------\n");

                            foreach (Person p in dekalb)
                            {
                                if (p.ResidenceIds.Contains(idToLook)) Console.WriteLine(p);
                            }
                        }

                        Console.WriteLine();

                        break;
                    case 6: // Toggle a property, by street address, as being for-sale or not.
                        Console.WriteLine("Enter the street address to lookup:");

                        // Get user input...
                        string addressToToggle = Console.ReadLine();

                        // Get id of property...
                        uint propToToggle = 0;

                        // Redundant way...but have no method of escaping just this case...
                        foreach (Property p in dekalb.Props)
                        {
                            if (addressToToggle == p.StreetAddr) propToToggle = p.Id;
                        }

                        // Check if address is valid...
                        if (propToToggle == 0)
                        {
                            Console.WriteLine("I'm sorry, I don't recognize this address: '{0}'.", addressToToggle);
                        }
                        else
                        {
                            foreach (Property p in dekalb.Props)
                            {
                                if (propToToggle == p.Id)
                                {
                                    if (p.Forsale)
                                    {
                                        Console.WriteLine("{0} is now listed as NOT for sale!", addressToToggle);
                                        p.Forsale = false;
                                    }
                                    else
                                    {
                                        Console.WriteLine("{0} is now listed as FOR SALE!", addressToToggle);
                                        p.Forsale = true;
                                    }
                                }
                            }
                        }

                        Console.WriteLine();

                        break;
                    case 7: // Buy a for-sale property, by street address.
                        Console.WriteLine("Enter the street address to lookup:");

                        // Get user input...
                        string addressToBuy = Console.ReadLine();

                        // Get id of property...
                        uint propToBuy = 0;

                        // Redundant way...but have no method of escaping just this case...
                        foreach (Property p in dekalb.Props)
                        {
                            if (addressToBuy == p.StreetAddr) propToBuy = p.Id;
                        }

                        // Check if address is valid...
                        if (propToBuy == 0)
                        {
                            Console.WriteLine("I'm sorry, I don't recognize this address: '{0}'.", addressToBuy);
                        }
                        else
                        {
                            foreach (Property p in dekalb.Props)
                            {
                                if (propToBuy == p.Id)
                                {
                                    if (p.Forsale)
                                    {
                                        Console.WriteLine("Congratulations! You have succesfully purchased this property!\n");
                                        p.Forsale = false;

                                        p.OwnerID = 0;

                                        foreach (Person person in dekalb.Residents)
                                        {
                                            if (person.Id == p.OwnerID)
                                            {
                                                Console.WriteLine(p.ToString(person.ToString()));
                                            }
                                        }
                                    }
                                    else
                                    {
                                        Console.WriteLine("Property is not for sale!");
                                    }
                                }
                            }
                        }

                        break;
                    case 8: // Add yourself as an occupant to a property.
                        Console.WriteLine("Enter the street address to lookup:");

                        // Get user input...
                        string addressToMoveIn = Console.ReadLine();

                        // Get id of property...
                        uint propToMoveIn = 0;

                        // Redundant way...but have no method of escaping just this case...
                        foreach (Property p in dekalb.Props)
                        {
                            if (addressToMoveIn == p.StreetAddr) propToMoveIn = p.Id;
                        }

                        // Check if address is valid...
                        if (propToMoveIn == 0)
                        {
                            Console.WriteLine("I'm sorry, I don't recognize this address: '{0}'.", addressToMoveIn);
                        }
                        else
                        {
                            foreach (Person p in dekalb)
                            {
                                // You...
                                if (p.Id == 0)
                                {
                                    if (p.ResidenceIds.Contains(propToMoveIn))
                                    {
                                        Console.WriteLine("You are already a resident at this property.");
                                    }
                                    else
                                    {
                                        p.addResidenceId(propToMoveIn);

                                        Console.WriteLine("Success! You have been added as a resident at this property.");
                                    }
                                }
                            }
                        }

                        Console.WriteLine();

                        break;
                    case 9: // Remove yourself as an occupant from a property.
                        Console.WriteLine("Enter the street address to lookup:");

                        // Get user input...
                        string addressToMoveOut = Console.ReadLine();

                        // Get id of property...
                        uint propToMoveOut = 0;

                        // Redundant way...but have no method of escaping just this case...
                        foreach (Property p in dekalb.Props)
                        {
                            if (addressToMoveOut == p.StreetAddr) propToMoveIn = p.Id;
                        }

                        // Check if address is valid...
                        if (propToMoveOut == 0)
                        {
                            Console.WriteLine("I'm sorry, I don't recognize this address: '{0}'.", addressToMoveOut);
                        }
                        else
                        {
                            foreach (Person p in dekalb)
                            {
                                // You...
                                if (p.Id == 0)
                                {
                                    if (p.ResidenceIds.Contains(propToMoveOut))
                                    {
                                        p.removeResidenceId(propToMoveOut);

                                        Console.WriteLine("Success! You have been removed as a resident at this property.");
                                    }
                                    else
                                    {
                                        Console.WriteLine("You do not currently reside at this property.");
                                    }
                                }
                            }
                        }

                        Console.WriteLine();

                        break;
                    case 10: // Quit.
                        Console.WriteLine("Quitting program...");
                        return;
                    default:
                        Console.WriteLine("Invalid input. Please enter a number from 1 to 10! Please try again!");
                        break;
                }

                // Print menu.
                Console.WriteLine(" 1. Full property list");
                Console.WriteLine(" 2. List addresses of either House or Apartment-type properties");
                Console.WriteLine(" 3. List addresses of all for-sale properties");
                Console.WriteLine(" 4. List all residents of a community");
                Console.WriteLine(" 5. List all residents of a property, by street address");
                Console.WriteLine(" 6. Toggle a property, by street address, as being for-sale or not.");
                Console.WriteLine(" 7. Buy a for-sale property, by street address");
                Console.WriteLine(" 8. Add yourself as an occupant to a property.");
                Console.WriteLine(" 9. Remove yourself as an occupant from a property");
                Console.WriteLine("10. Quit\n");

                userInput = Console.ReadLine().Split();
            }
        }
    }
}